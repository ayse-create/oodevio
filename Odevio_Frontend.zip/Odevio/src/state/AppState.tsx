import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  type ReactNode,
  type DependencyList,
} from "react";
import type { RequestState, Session } from "../models";
import { authService } from "../services/authService";
import { apiConfig } from "../services/config";
const Context = createContext({
  revision: 0,
  refresh: () => {},
  sessionReady: !apiConfig.enabled,
  session: null as Session | null,
  setSession: (_s: Session | null) => {},
});
export function AppState({ children }: { children: ReactNode }) {
  const [revision, setRevision] = useState(0);
  const [sessionReady, setSessionReady] = useState(!apiConfig.enabled);
  const [session, setSession] = useState<Session | null>(null);
  const refresh = useCallback(() => setRevision((x) => x + 1), []);
  useEffect(() => {
    authService
      .session()
      .then(setSession)
      .catch(() => setSession(null))
      .finally(() => setSessionReady(true));
  }, []);
  return (
    <Context.Provider
      value={{ revision, refresh, session, setSession, sessionReady }}
    >
      {children}
    </Context.Provider>
  );
}
export const useApp = () => useContext(Context);
export function useQuery<T>(load: () => Promise<T>, deps: DependencyList = []) {
  const { revision } = useApp();
  const [retry, setRetry] = useState(0);
  const [state, setState] = useState<RequestState<T>>({ status: "loading" });
  useEffect(() => {
    let active = true;
    setState({ status: "loading" });
    load()
      .then((data) => {
        if (active) setState({ status: "success", data });
      })
      .catch((error) => {
        if (active)
          setState({
            status: "error",
            error:
              error instanceof Error ? error : new Error("Bir sorun oluştu."),
          });
      });
    return () => {
      active = false;
    };
  }, [...deps, revision, retry]);
  return { state, retry: () => setRetry((x) => x + 1) };
}
