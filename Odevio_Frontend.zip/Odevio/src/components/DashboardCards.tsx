import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  BookOpen,
  Target,
  MessageCircle,
  Check,
  Heart,
} from "lucide-react";
import { Empty, Badge } from "./ui";
import type {
  DailySummary,
  Homework,
  Subject,
  TeacherMessage,
} from "../models";
import { messagePresets } from "../models/options";
import { localDate } from "../validation";
export function CalendarLeaf() {
  const [today, setToday] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setToday(new Date()), 60000);
    return () => clearInterval(t);
  }, []);
  const first = new Date(today.getFullYear(), today.getMonth(), 1);
  const count = new Date(
    today.getFullYear(),
    today.getMonth() + 1,
    0,
  ).getDate();
  const padding = (first.getDay() + 6) % 7;
  return (
    <section className="calendar-leaf" aria-label="Bu ayın takvimi">
      <div className="calendar-rings" aria-hidden="true">
        <i />
        <i />
      </div>
      <div className="calendar-title">
        <strong>{today.toLocaleDateString("tr-TR", { month: "long" })}</strong>
        <span>{today.getFullYear()}</span>
      </div>
      <div className="calendar-grid">
        {["P", "S", "Ç", "P", "C", "C", "P"].map((d, i) => (
          <span className="day-label" key={"d" + i}>
            {d}
          </span>
        ))}
        {Array.from({ length: padding }, (_, i) => (
          <span key={"p" + i} />
        ))}
        {Array.from({ length: count }, (_, i) => (
          <span
            key={i}
            className={i + 1 === today.getDate() ? "today" : ""}
            aria-current={i + 1 === today.getDate() ? "date" : undefined}
          >
            {i + 1}
          </span>
        ))}
      </div>
    </section>
  );
}
export function Clock() {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const t = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  return (
    <section className="clock-card">
      <div
        className="clock-face"
        role="img"
        aria-label={`Saat ${time.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" })}`}
      >
        <svg viewBox="0 0 200 200" aria-hidden="true">
          {Array.from({ length: 12 }, (_, i) => (
            <line
              key={i}
              x1="100"
              y1="17"
              x2="100"
              y2={i % 3 === 0 ? "29" : "23"}
              transform={`rotate(${i * 30} 100 100)`}
              stroke="currentColor"
              strokeWidth={i % 3 === 0 ? 3 : 1.5}
            />
          ))}
          <line
            x1="100"
            y1="108"
            x2="100"
            y2="53"
            stroke="currentColor"
            strokeWidth="5"
            strokeLinecap="round"
            transform={`rotate(${(time.getHours() % 12) * 30 + time.getMinutes() / 2} 100 100)`}
          />
          <line
            x1="100"
            y1="110"
            x2="100"
            y2="34"
            stroke="currentColor"
            strokeWidth="3"
            strokeLinecap="round"
            transform={`rotate(${time.getMinutes() * 6} 100 100)`}
          />
          <line
            x1="100"
            y1="112"
            x2="100"
            y2="31"
            stroke="var(--accent)"
            strokeWidth="1.5"
            transform={`rotate(${time.getSeconds() * 6} 100 100)`}
          />
          <circle cx="100" cy="100" r="5" fill="var(--accent)" />
        </svg>
      </div>
      <span>Her şey kendi zamanında.</span>
    </section>
  );
}
export function MessageCard({ messages }: { messages: TeacherMessage[] }) {
  return (
    <section className="message-card">
      <div className="card-label">
        <MessageCircle size={18} />
        <span>ÖĞRETMENİNDEN</span>
      </div>
      {messages.length ? (
        <div className="messages-scroll">
          {[...messages]
            .sort((a, b) => b.sentAt.localeCompare(a.sentAt))
            .slice(0, 3)
            .map((m) => (
              <div className="received-message" key={m.id}>
                <Heart size={18} />
                <strong>{messagePresets[m.preset]}</strong>
                <small>
                  {m.teacherName} ·{" "}
                  {new Date(m.sentAt).toLocaleDateString("tr-TR")}
                </small>
              </div>
            ))}
        </div>
      ) : (
        <>
          <div className="message-mark" aria-hidden="true">
            “
          </div>
          <h3>
            Henüz öğretmen
            <br />
            mesajın yok.
          </h3>
          <p>
            Öğretmeninin küçük destekleri
            <br />
            burada seni bekleyecek.
          </p>
        </>
      )}
    </section>
  );
}
export function HomeworkSummary({
  homework,
  subjects,
}: {
  homework: Homework[];
  subjects: Subject[];
}) {
  return (
    <section className="homework-summary">
      <header className="card-heading">
        <h2>
          Bütün Ödevlerim <span className="count">{homework.length}</span>
        </h2>
        <Link
          to="/ogrenci/odevler"
          className="icon-btn"
          aria-label="Bütün ödevler sayfasını aç"
        >
          <ArrowUpRight size={20} />
        </Link>
      </header>
      <div
        className="homework-scroll"
        tabIndex={0}
        role="region"
        aria-label="Kaydırılabilir kısa ödev listesi"
      >
        {homework.length ? (
          homework.map((h) => (
            <Link
              key={h.id}
              className="homework-mini-row"
              to={`/ogrenci/odevler/${h.id}`}
            >
              <strong>
                {subjects.find((s) => s.id === h.subjectId)?.name || "Ders"}
              </strong>
              <span>— {h.description}</span>
            </Link>
          ))
        ) : (
          <Empty
            title="Henüz ödevin yok."
            description="İlk ödevinle yeni bir sayfa aç."
            action="Yeni ödev ekle"
            to="/ogrenci/odevler?yeni=1"
            icon={<BookOpen size={32} strokeWidth={1.4} />}
          />
        )}
      </div>
    </section>
  );
}
export function SummaryCard({ summary }: { summary: DailySummary }) {
  const percentage =
    summary.target > 0
      ? Math.min(
          100,
          Math.round((summary.totalQuestions / summary.target) * 100),
        )
      : 0;
  return (
    <section className="summary-card">
      <header className="card-heading">
        <h2>Bugünkü Emeğin</h2>
        <Target size={21} />
      </header>
      <div className="question-total">
        <strong>{summary.totalQuestions}</strong>
        <span>çözülen soru</span>
      </div>
      <div className="summary-stats">
        <div>
          <span className="stat-icon correct">✓</span>
          <strong>{summary.correct}</strong>
          <span>Doğru</span>
        </div>
        <div>
          <span className="stat-icon wrong">×</span>
          <strong>{summary.wrong}</strong>
          <span>Yanlış</span>
        </div>
        <div>
          <Target size={18} />
          <strong>{summary.target}</strong>
          <span>Günlük hedef</span>
        </div>
      </div>
      <div className="progress-label">
        <span>Hedefine doğru</span>
        <strong>%{percentage}</strong>
      </div>
      <progress
        value={percentage}
        max={100}
        aria-label="Günlük hedef ilerlemesi"
      />
      <p className="helper">
        {summary.target === 0
          ? "Bir hedef belirle, küçük adımlarla ilerle."
          : percentage === 100
            ? "Bugünkü hedefine ulaştın. Emeğine sağlık!"
            : `${Math.max(0, summary.target - summary.totalQuestions)} soru daha, hedefin tamam.`}
      </p>
      <Link className="text-link" to="/ogrenci/hedefler">
        Günlük hedeflerim <ArrowUpRight size={16} />
      </Link>
    </section>
  );
}
