import {
  TrendingUp,
  TrendingDown,
  Minus,
  ChartNoAxesCombined,
} from "lucide-react";
import type { MockExam, Subject } from "../models";
import { Empty, Badge } from "./ui";
import { dateLabel, localDate } from "../validation";
export function ExamAnalysis({
  exams,
  subjects,
}: {
  exams: MockExam[];
  subjects: Subject[];
}) {
  const cutoff = new Date();
  cutoff.setMonth(cutoff.getMonth() - 3);
  const recent = exams
    .filter((e) => e.date >= localDate(cutoff) && e.date <= localDate())
    .sort((a, b) => a.date.localeCompare(b.date));
  const series = subjects
    .map((s) => ({
      subject: s,
      points: recent.flatMap((e) => {
        const r = e.subjectResults.find((r) => r.subjectId === s.id);
        return r ? [{ date: e.date, value: r.net, name: e.name }] : [];
      }),
    }))
    .filter((s) => s.points.length >= 2);
  if (!series.length)
    return (
      <div className="analysis-empty paper-panel">
        <Empty
          title="Gelişim analizi için yeterli veri yok."
          description="Son üç ayda aynı derse ait en az iki deneme sonucu eklendiğinde net değişimini burada görebilirsin."
          icon={<ChartNoAxesCombined size={34} strokeWidth={1.4} />}
        />
      </div>
    );
  const averageChange =
    series.reduce(
      (sum, s) => sum + s.points.at(-1)!.value - s.points[0].value,
      0,
    ) / series.length;
  return (
    <>
      <div className="analysis-overview">
        <div>
          <span className="eyebrow">SON ÜÇ AY</span>
          <h2>
            Genel eğilim:{" "}
            {averageChange > 0
              ? "Artış"
              : averageChange < 0
                ? "Düşüş"
                : "Sabit"}
          </h2>
          <p>
            Karşılaştırılabilir derslerin ilk ve son netleri arasında ortalama{" "}
            {averageChange.toFixed(2)} net değişim.
          </p>
        </div>
        <Badge>{recent.length} deneme</Badge>
      </div>
      <div className="cards-grid">
        {series.map(({ subject, points }) => {
          const delta = points.at(-1)!.value - points[0].value;
          const min = Math.min(0, ...points.map((p) => p.value));
          const max = Math.max(1, ...points.map((p) => p.value));
          const y = (v: number) => 130 - ((v - min) / (max - min)) * 104;
          const x = (i: number) => 36 + (i / (points.length - 1)) * 284;
          return (
            <article className="item-card" key={subject.id}>
              <div className="item-top">
                <h3>{subject.name}</h3>
                <Badge tone={delta > 0 ? "green" : ""}>
                  {delta > 0 ? (
                    <TrendingUp size={15} />
                  ) : delta < 0 ? (
                    <TrendingDown size={15} />
                  ) : (
                    <Minus size={15} />
                  )}{" "}
                  {delta > 0 ? "+" : ""}
                  {delta.toFixed(2)} net ·{" "}
                  {delta > 0 ? "Artış" : delta < 0 ? "Düşüş" : "Sabit"}
                </Badge>
              </div>
              <svg
                className="trend-chart"
                viewBox="0 0 350 164"
                role="img"
                aria-label={`${subject.name}: ${points[0].value} netten ${points.at(-1)!.value} nete. ${delta.toFixed(2)} net değişim.`}
              >
                <line x1="36" x2="320" y1="130" y2="130" stroke="var(--line)" />
                <line
                  x1="36"
                  x2="320"
                  y1="26"
                  y2="26"
                  stroke="var(--line)"
                  strokeDasharray="4 4"
                />
                <text x="4" y="31">
                  {max}
                </text>
                <text x="4" y="133">
                  {min}
                </text>
                <polyline
                  points={points
                    .map((p, i) => `${x(i)},${y(p.value)}`)
                    .join(" ")}
                  fill="none"
                  stroke="var(--accent)"
                  strokeWidth="3"
                />
                {points.map((p, i) => (
                  <circle
                    key={i}
                    cx={x(i)}
                    cy={y(p.value)}
                    r="4"
                    fill="var(--accent)"
                  >
                    <title>
                      {p.name}: {p.value} net
                    </title>
                  </circle>
                ))}
                <text x="36" y="156">
                  {dateLabel(points[0].date)}
                </text>
                <text x="320" y="156" textAnchor="end">
                  {dateLabel(points.at(-1)!.date)}
                </text>
              </svg>
              <details>
                <summary>Sonuçları tablo olarak göster</summary>
                <table>
                  <thead>
                    <tr>
                      <th>Tarih</th>
                      <th>Deneme</th>
                      <th>Net</th>
                    </tr>
                  </thead>
                  <tbody>
                    {points.map((p, i) => (
                      <tr key={i}>
                        <td>{dateLabel(p.date)}</td>
                        <td>{p.name}</td>
                        <td>{p.value}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </details>
            </article>
          );
        })}
      </div>
      <p className="page-hint">
        Netler kaydedilen denemenin hesaplama kuralına göre gösterilir. Farklı
        soru sayıları ve net kuralları karşılaştırmayı etkileyebilir.
      </p>
    </>
  );
}
