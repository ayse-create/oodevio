import {
  useEffect,
  useRef,
  useId,
  useState,
  type ReactNode,
  type FormEvent,
} from "react";
import {
  BookOpen,
  Plus,
  X,
  AlertCircle,
  LockKeyhole,
  LoaderCircle,
  CheckCircle2,
  ArrowRight,
} from "lucide-react";
import { Link } from "react-router-dom";
import type { RequestState } from "../models";
import { ApiError } from "../services/client";
import { useApp } from "../state/AppState";
export function Empty({
  title,
  description,
  action,
  onAction,
  to,
  icon,
}: {
  title: string;
  description?: string;
  action?: string;
  onAction?: () => void;
  to?: string;
  icon?: ReactNode;
}) {
  return (
    <div className="empty">
      <div className="empty-symbol">
        {icon || <BookOpen size={30} strokeWidth={1.4} />}
      </div>
      <h3>{title}</h3>
      {description && <p>{description}</p>}
      {action &&
        (to ? (
          <Link className="btn soft" to={to}>
            <Plus size={16} />
            {action}
          </Link>
        ) : (
          <button className="btn soft" onClick={onAction}>
            <Plus size={16} />
            {action}
          </button>
        ))}
    </div>
  );
}
export function Status<T>({
  state,
  retry,
  children,
}: {
  state: RequestState<T>;
  retry: () => void;
  children: (data: T) => ReactNode;
}) {
  if (state.status === "loading")
    return (
      <div className="status" role="status">
        <LoaderCircle className="spin" />
        <p>Sayfan hazırlanıyor…</p>
      </div>
    );
  if (state.status === "error") {
    const denied =
      state.error instanceof ApiError &&
      ["UNAUTHORIZED", "FORBIDDEN"].includes(state.error.code);
    return (
      <div className="status error" role="alert">
        {denied ? <LockKeyhole /> : <AlertCircle />}
        <h3>{denied ? "Bu sayfaya erişilemiyor" : "Sayfa yüklenemedi"}</h3>
        <p>{state.error.message}</p>
        {denied ? (
          <Link className="btn" to="/giris">
            Giriş ekranına git
          </Link>
        ) : (
          <button className="btn" onClick={retry}>
            Yeniden dene
          </button>
        )}
      </div>
    );
  }
  return <>{children(state.data)}</>;
}
export function PageTitle({
  eyebrow,
  title,
  description,
  action,
}: {
  eyebrow?: string;
  title: string;
  description?: string;
  action?: ReactNode;
}) {
  return (
    <header className="page-title">
      <div>
        {eyebrow && <span className="eyebrow">{eyebrow}</span>}
        <h1>{title}</h1>
        {description && <p>{description}</p>}
      </div>
      {action}
    </header>
  );
}
export function AddButton({
  children,
  onClick,
}: {
  children: ReactNode;
  onClick: () => void;
}) {
  return (
    <button className="btn" onClick={onClick}>
      <Plus size={18} />
      {children}
    </button>
  );
}
export function Modal({
  title,
  onClose,
  children,
  danger = false,
}: {
  title: string;
  onClose: () => void;
  children: ReactNode;
  danger?: boolean;
}) {
  const ref = useRef<HTMLDialogElement>(null);
  const id = useId();
  useEffect(() => {
    const active = document.activeElement as HTMLElement;
    ref.current?.showModal();
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
      active?.focus();
    };
  }, []);
  return (
    <dialog
      ref={ref}
      aria-labelledby={id}
      className={`modal ${danger ? "danger-modal" : ""}`}
      onCancel={(e) => {
        e.preventDefault();
        onClose();
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div className="modal-header">
        <h2 id={id}>{title}</h2>
        <button
          className="icon-btn"
          aria-label="Pencereyi kapat"
          onClick={onClose}
        >
          <X />
        </button>
      </div>
      {children}
    </dialog>
  );
}
export function Field({
  label,
  children,
  hint,
}: {
  label: string;
  children: (id: string) => ReactNode;
  hint?: string;
}) {
  const id = useId();
  return (
    <div className="field">
      <label htmlFor={id}>{label}</label>
      {children(id)}
      {hint && <small>{hint}</small>}
    </div>
  );
}
export function TextField({
  label,
  value,
  onChange,
  type = "text",
  required = false,
  min,
  max,
  step,
  placeholder,
  autoComplete,
  maxLength,
}: {
  label: string;
  value: string | number;
  onChange: (v: string) => void;
  type?: string;
  required?: boolean;
  min?: string | number;
  max?: string | number;
  step?: number;
  placeholder?: string;
  autoComplete?: string;
  maxLength?: number;
}) {
  return (
    <Field label={label}>
      {(id) => (
        <input
          id={id}
          type={type}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
          min={min}
          max={max}
          step={step}
          placeholder={placeholder}
          autoComplete={autoComplete}
          maxLength={maxLength}
        />
      )}
    </Field>
  );
}
export function TextArea({
  label,
  value,
  onChange,
  required = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <Field label={label}>
      {(id) => (
        <textarea
          id={id}
          rows={4}
          maxLength={5000}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
        />
      )}
    </Field>
  );
}
export function SelectField({
  label,
  value,
  onChange,
  options,
  required = false,
  empty = "Seçiniz",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
  required?: boolean;
  empty?: string;
}) {
  return (
    <Field label={label}>
      {(id) => (
        <select
          id={id}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          required={required}
        >
          <option value="">{empty}</option>
          {options.map((o) => (
            <option key={o.value} value={o.value}>
              {o.label}
            </option>
          ))}
        </select>
      )}
    </Field>
  );
}
export function SaveForm({
  children,
  onSave,
  onSuccess,
  label = "Kaydet",
  validate,
  disabled = false,
}: {
  children: ReactNode;
  onSave: () => Promise<unknown>;
  onSuccess?: () => void;
  label?: string;
  validate?: () => string | null;
  disabled?: boolean;
}) {
  const [state, setState] = useState<"idle" | "busy" | "success" | "error">(
    "idle",
  );
  const [error, setError] = useState("");
  const { refresh } = useApp();
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    const err = validate?.();
    if (err) {
      setError(err);
      setState("error");
      return;
    }
    setState("busy");
    try {
      await onSave();
      setState("success");
      refresh();
      onSuccess?.();
    } catch (e) {
      setState("error");
      setError(e instanceof Error ? e.message : "İşlem tamamlanamadı.");
    }
  };
  return (
    <form
      onSubmit={submit}
      className="form"
      onInput={() => {
        if (state === "success") setState("idle");
      }}
    >
      {children}
      {state === "error" && (
        <div role="alert" className="form-message error">
          <AlertCircle size={19} />
          <span>{error}</span>
        </div>
      )}
      {state === "success" && (
        <div role="status" className="form-message success">
          <CheckCircle2 size={19} />
          İşlem başarıyla tamamlandı.
        </div>
      )}
      <div className="form-footer">
        <button
          className="btn"
          type="submit"
          disabled={state === "busy" || disabled}
        >
          {state === "busy" ? (
            <>
              <LoaderCircle size={17} className="spin" />
              İşleniyor…
            </>
          ) : (
            <>
              {label}
              <ArrowRight size={17} />
            </>
          )}
        </button>
      </div>
    </form>
  );
}
export function Tabs({
  items,
  value,
  onChange,
}: {
  items: { id: string; label: string }[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div className="tabs" role="group" aria-label="Görünüm seçimi">
      {items.map((t) => (
        <button
          key={t.id}
          aria-pressed={value === t.id}
          className={value === t.id ? "active" : ""}
          onClick={() => onChange(t.id)}
        >
          {t.label}
        </button>
      ))}
    </div>
  );
}
export function Badge({
  children,
  tone = "",
}: {
  children: ReactNode;
  tone?: string;
}) {
  return <span className={`badge ${tone}`}>{children}</span>;
}
export function Confirm({
  title,
  description,
  onClose,
  onConfirm,
}: {
  title: string;
  description: string;
  onClose: () => void;
  onConfirm: () => Promise<unknown>;
}) {
  return (
    <Modal title={title} onClose={onClose} danger>
      <p>{description}</p>
      <SaveForm label="Evet, sil" onSave={onConfirm} onSuccess={onClose}>
        <button type="button" className="btn secondary" onClick={onClose}>
          Vazgeç
        </button>
      </SaveForm>
    </Modal>
  );
}
