import { Plus, Trash2 } from "lucide-react";
import { SelectField, TextField, Status, Field } from "./ui";
import type { Subject, WrongTopic } from "../models";
import { subjectService } from "../services/subjectService";
import { useQuery } from "../state/AppState";
export function SubjectSelect({
  value,
  onChange,
  subjects,
}: {
  value: string;
  onChange: (v: string) => void;
  subjects: Subject[];
}) {
  return (
    <SelectField
      label="Ders"
      value={value}
      onChange={onChange}
      required
      empty={subjects.length ? "Ders seç" : "Henüz seçilmiş ders yok"}
      options={subjects.map((s) => ({ value: s.id, label: s.name }))}
    />
  );
}
export function SubjectPicker({
  selected,
  onChange,
}: {
  selected: string[];
  onChange: (ids: string[]) => void;
}) {
  const q = useQuery(subjectService.list);
  return (
    <fieldset>
      <legend>Ders seçimi</legend>
      <Status {...q}>
        {(subjects) =>
          subjects.length ? (
            <div className="checks">
              {subjects.map((s) => (
                <label key={s.id}>
                  <input
                    type="checkbox"
                    checked={selected.includes(s.id)}
                    onChange={(e) =>
                      onChange(
                        e.target.checked
                          ? [...selected, s.id]
                          : selected.filter((id) => id !== s.id),
                      )
                    }
                  />
                  {s.name}
                </label>
              ))}
            </div>
          ) : (
            <p className="helper">
              Ders listesi bağlantı kurulduğunda burada görünecek.
            </p>
          )
        }
      </Status>
    </fieldset>
  );
}
export function WrongTopics({
  value,
  onChange,
  wrong,
}: {
  value: WrongTopic[];
  onChange: (v: WrongTopic[]) => void;
  wrong: number;
}) {
  if (wrong <= 0) return null;
  return (
    <fieldset className="topic-fields">
      <legend>Yanlışların konuları</legend>
      <p className="helper">
        Her konuya ait yanlış sayısını belirt. Toplam {wrong} yanlış olmalı.
      </p>
      {value.map((t, i) => (
        <div className="topic-row" key={i}>
          <TextField
            label={`Konu ${i + 1}`}
            value={t.topic}
            onChange={(v) =>
              onChange(value.map((x, n) => (n === i ? { ...x, topic: v } : x)))
            }
            required
          />
          <TextField
            label="Yanlış"
            type="number"
            min={1}
            step={1}
            value={t.count}
            onChange={(v) =>
              onChange(
                value.map((x, n) => (n === i ? { ...x, count: Number(v) } : x)),
              )
            }
            required
          />
          <button
            type="button"
            className="icon-btn"
            aria-label={`${i + 1}. yanlış konusunu kaldır`}
            onClick={() => onChange(value.filter((_, n) => n !== i))}
          >
            <Trash2 size={18} />
          </button>
        </div>
      ))}
      <button
        type="button"
        className="btn secondary small"
        onClick={() => onChange([...value, { topic: "", count: 1 }])}
      >
        <Plus size={16} />
        Konu ekle
      </button>
    </fieldset>
  );
}
export function CodeField({
  value,
  onChange,
}: {
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <Field label="Altı haneli öğrenci kodu">
      {(id) => (
        <input
          id={id}
          className="code-input"
          value={value}
          inputMode="numeric"
          pattern="[0-9]{6}"
          maxLength={6}
          autoComplete="off"
          placeholder="------"
          required
          onChange={(e) =>
            onChange(e.target.value.replace(/\D/g, "").slice(0, 6))
          }
        />
      )}
    </Field>
  );
}
