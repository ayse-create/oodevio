import { useState, useEffect } from "react";
import { Target, Plus, ArrowUp, ArrowDown, Trash2, Check } from "lucide-react";
import type {
  DailyGoal,
  Subject,
  GoalPattern,
  WrongTopic,
  DailyPracticeResult,
} from "../models";
import { goalService } from "../services/goalService";
import { subjectService } from "../services/subjectService";
import { useQuery } from "../state/AppState";
import {
  PageTitle,
  AddButton,
  Empty,
  Status,
  Tabs,
  Modal,
  SaveForm,
  TextField,
  SelectField,
  Badge,
} from "../components/ui";
import { SubjectSelect, WrongTopics } from "../components/DomainFields";
import { weekdays } from "../models/options";
import {
  localDate,
  dateLabel,
  validateResults,
  validatePattern,
  goalSubjectOnDate,
} from "../validation";
const patternNames = {
  once: "Tek gün",
  daily: "Her gün",
  weekdays: "Belirli günler",
  alternating: "Dönüşümlü dersler",
};
export function GoalForm({
  subjects,
  existing,
  onClose,
}: {
  subjects: Subject[];
  existing?: DailyGoal;
  onClose: () => void;
}) {
  const [title, setTitle] = useState(existing?.title || "");
  const [subject, setSubject] = useState(existing?.subjectId || "");
  const [target, setTarget] = useState<string | number>(
    existing?.questionTarget ?? "",
  );
  const [type, setType] = useState<GoalPattern["type"]>(
    existing?.pattern.type || "once",
  );
  const [date, setDate] = useState(
    existing
      ? existing.pattern.type === "once"
        ? existing.pattern.date
        : existing.pattern.startDate
      : localDate(),
  );
  const [days, setDays] = useState<number[]>(
    existing?.pattern.type === "weekdays" ? existing.pattern.days : [],
  );
  const [sequence, setSequence] = useState<string[]>(
    existing?.pattern.type === "alternating" ? existing.pattern.subjectIds : [],
  );
  const [active, setActive] = useState(existing?.active ?? true);
  const pattern = (): GoalPattern =>
    type === "once"
      ? { type, date }
      : type === "daily"
        ? { type, startDate: date }
        : type === "weekdays"
          ? { type, startDate: date, days }
          : { type, startDate: date, subjectIds: sequence };
  function move(i: number, delta: number) {
    const next = [...sequence];
    [next[i], next[i + delta]] = [next[i + delta], next[i]];
    setSequence(next);
  }
  return (
    <Modal
      title={existing ? "Hedefini düzenle" : "Yeni bir hedef belirle"}
      onClose={onClose}
    >
      <SaveForm
        validate={() =>
          !title.trim() ? "Hedefine bir ad ver." : validatePattern(pattern())
        }
        onSuccess={onClose}
        onSave={() => {
          const input = {
            title: title.trim(),
            subjectId: type === "alternating" ? sequence[0] : subject,
            questionTarget: Number(target),
            pattern: pattern(),
            active,
          };
          return existing
            ? goalService.update(existing.id, input)
            : goalService.create(input);
        }}
      >
        <TextField
          label="Hedef adı"
          required
          value={title}
          onChange={setTitle}
        />
        <SelectField
          label="Hedef düzeni"
          required
          value={type}
          onChange={(v) => setType(v as typeof type)}
          options={Object.entries(patternNames).map(([value, label]) => ({
            value,
            label,
          }))}
        />
        {type !== "alternating" && (
          <SubjectSelect
            subjects={subjects}
            value={subject}
            onChange={setSubject}
          />
        )}
        <div className="form-grid">
          <TextField
            label="Günlük soru hedefi"
            required
            type="number"
            min={1}
            step={1}
            value={target}
            onChange={setTarget}
          />
          <TextField
            label={type === "once" ? "Hedef tarihi" : "Başlangıç tarihi"}
            required
            type="date"
            value={date}
            onChange={setDate}
          />
        </div>
        {type === "weekdays" && (
          <fieldset>
            <legend>Hangi günler?</legend>
            <div className="checks">
              {weekdays.map((day, i) => (
                <label key={day}>
                  <input
                    type="checkbox"
                    checked={days.includes(i + 1)}
                    onChange={(e) =>
                      setDays(
                        e.target.checked
                          ? [...days, i + 1]
                          : days.filter((d) => d !== i + 1),
                      )
                    }
                  />
                  {day}
                </label>
              ))}
            </div>
          </fieldset>
        )}
        {type === "alternating" && (
          <fieldset>
            <legend>Derslerin dönüşüm sırası</legend>
            <p className="helper">
              Başlangıç gününde ilk ders çalışılır. Sıra her gün bir sonraki
              derse geçer.
            </p>
            <div className="checks">
              {subjects.map((s) => (
                <label key={s.id}>
                  <input
                    type="checkbox"
                    checked={sequence.includes(s.id)}
                    onChange={(e) =>
                      setSequence(
                        e.target.checked
                          ? [...sequence, s.id]
                          : sequence.filter((id) => id !== s.id),
                      )
                    }
                  />
                  {s.name}
                </label>
              ))}
            </div>
            {!subjects.length && (
              <p className="helper">Ders listesi henüz yüklenmedi.</p>
            )}
            {sequence.map((id, i) => (
              <div className="sequence-row" key={id}>
                <span>
                  {i + 1}. {subjects.find((s) => s.id === id)?.name}
                </span>
                <button
                  type="button"
                  className="icon-btn"
                  aria-label="Dersi önceye al"
                  disabled={i === 0}
                  onClick={() => move(i, -1)}
                >
                  <ArrowUp size={16} />
                </button>
                <button
                  type="button"
                  className="icon-btn"
                  aria-label="Dersi sonraya al"
                  disabled={i === sequence.length - 1}
                  onClick={() => move(i, 1)}
                >
                  <ArrowDown size={16} />
                </button>
              </div>
            ))}
          </fieldset>
        )}
        {existing && (
          <label className="check-label">
            <input
              type="checkbox"
              checked={active}
              onChange={(e) => setActive(e.target.checked)}
            />
            Hedef aktif
          </label>
        )}
      </SaveForm>
    </Modal>
  );
}
export function PracticeForm({
  subjects,
  goals,
  onClose,
  initialGoal,
}: {
  subjects: Subject[];
  goals: DailyGoal[];
  onClose: () => void;
  initialGoal?: DailyGoal;
}) {
  const [goalId, setGoalId] = useState(initialGoal?.id || "");
  const [subject, setSubject] = useState(initialGoal?.subjectId || "");
  const [date, setDate] = useState(localDate());
  const [correct, setCorrect] = useState("");
  const [wrong, setWrong] = useState("");
  const [topics, setTopics] = useState<WrongTopic[]>([]);
  const chosenGoal = goals.find((g) => g.id === goalId);
  useEffect(() => {
    if (chosenGoal) {
      setSubject(goalSubjectOnDate(chosenGoal, date) || "");
    }
  }, [goalId, date]);
  return (
    <Modal title="Çalışma sonucunu ekle" onClose={onClose}>
      <SaveForm
        onSuccess={onClose}
        validate={() =>
          chosenGoal && !goalSubjectOnDate(chosenGoal, date)
            ? "Bu hedef seçilen günde aktif değil. Tarihi değiştir veya ekstra çalışma olarak ekle."
            : chosenGoal && subject !== goalSubjectOnDate(chosenGoal, date)
              ? "Ders, hedefin seçilen gündeki dersiyle aynı olmalı."
              : Number(correct) + Number(wrong) < 1
                ? "En az bir çözülen soru gir."
                : validateResults(Number(correct), Number(wrong), topics)
        }
        onSave={() =>
          goalService.recordPractice({
            goalId: goalId || null,
            subjectId: subject,
            date,
            correct: Number(correct),
            wrong: Number(wrong),
            wrongTopics: Number(wrong) > 0 ? topics : [],
            source: goalId ? "goal" : "extra",
          })
        }
      >
        <SelectField
          label="Bağlı hedef (isteğe bağlı)"
          empty="Ekstra çalışma"
          value={goalId}
          onChange={(v) => {
            setGoalId(v);
            const g = goals.find((g) => g.id === v);
            if (g) setSubject(g.subjectId);
          }}
          options={goals.map((g) => ({ value: g.id, label: g.title }))}
        />
        <SubjectSelect
          subjects={subjects}
          value={subject}
          onChange={setSubject}
        />
        <TextField
          label="Çalışma tarihi"
          type="date"
          max={localDate()}
          required
          value={date}
          onChange={setDate}
        />
        <div className="form-grid">
          <TextField
            label="Doğru sayısı"
            type="number"
            min={0}
            step={1}
            required
            value={correct}
            onChange={setCorrect}
          />
          <TextField
            label="Yanlış sayısı"
            type="number"
            min={0}
            step={1}
            required
            value={wrong}
            onChange={setWrong}
          />
        </div>
        <WrongTopics
          value={topics}
          onChange={setTopics}
          wrong={Number(wrong)}
        />
        <p className="helper">
          Kaydedilen yanlışların Yanlış Defteri’nde de yer alacak.
        </p>
      </SaveForm>
    </Modal>
  );
}
export function GoalCard({
  goal: g,
  results,
  subjects,
  onEdit,
  onResult,
}: {
  goal: DailyGoal;
  results: DailyPracticeResult[];
  subjects: Subject[];
  onEdit?: () => void;
  onResult?: () => void;
}) {
  const todayResults = results.filter(
    (r) => r.goalId === g.id && r.date === localDate(),
  );
  const todaySubject = goalSubjectOnDate(g, localDate());
  const total = todayResults.reduce((s, r) => s + r.correct + r.wrong, 0);
  const correct = todayResults.reduce((s, r) => s + r.correct, 0);
  const wrong = todayResults.reduce((s, r) => s + r.wrong, 0);
  return (
    <article className="item-card">
      <div className="item-top">
        <Badge>{patternNames[g.pattern.type]}</Badge>
        <Badge tone={g.active ? "green" : ""}>
          {g.active ? "Aktif" : "Duraklatıldı"}
        </Badge>
      </div>
      <h3>{g.title}</h3>
      <p>
        {g.pattern.type === "alternating"
          ? g.pattern.subjectIds
              .map((id) => subjects.find((s) => s.id === id)?.name || "Ders")
              .join(" → ")
          : subjects.find((s) => s.id === g.subjectId)?.name}{" "}
        · {g.questionTarget} soru
      </p>
      <p className="helper">
        {g.pattern.type === "weekdays"
          ? g.pattern.days.map((d) => weekdays[d - 1]).join(", ")
          : g.pattern.type === "once"
            ? dateLabel(g.pattern.date)
            : `${dateLabel(g.pattern.startDate)} tarihinden itibaren`}
      </p>
      <progress
        value={Math.min(total, g.questionTarget)}
        max={g.questionTarget}
        aria-label={`${g.title} ilerlemesi`}
      />
      <p>
        {total} / {g.questionTarget} soru · {correct} doğru · {wrong} yanlış
      </p>
      <Badge tone={total >= g.questionTarget ? "green" : ""}>
        {!todaySubject
          ? "Bugün için planlanmadı"
          : total >= g.questionTarget
            ? "Hedefe ulaşıldı"
            : "Hedef devam ediyor"}
      </Badge>
      {onEdit && (
        <div className="action-row">
          <button className="btn secondary small" onClick={onEdit}>
            Düzenle
          </button>
          <button className="btn small" onClick={onResult}>
            Sonuç gir
          </button>
        </div>
      )}
    </article>
  );
}
export function GoalsPage() {
  const [view, setView] = useState("goals");
  const [form, setForm] = useState<"goal" | "practice" | null>(null);
  const [editing, setEditing] = useState<DailyGoal | undefined>();
  const [initialGoal, setInitialGoal] = useState<DailyGoal | undefined>();
  const [historyDate, setHistoryDate] = useState("");
  const q = useQuery(async () => {
    const [goals, results, subjects] = await Promise.all([
      goalService.list(),
      goalService.listResults(),
      subjectService.listSelected(),
    ]);
    return { goals, results, subjects };
  });
  return (
    <>
      <PageTitle
        eyebrow="ADIM ADIM İLERLE"
        title="Ekstralar ve Günlük Hedefler"
        description="Hedefini belirle, emeğini görünür kıl."
        action={
          <AddButton
            onClick={() => {
              setEditing(undefined);
              setForm("goal");
            }}
          >
            Yeni hedef
          </AddButton>
        }
      />
      <div className="toolbar">
        <Tabs
          value={view}
          onChange={setView}
          items={[
            { id: "goals", label: "Hedeflerim" },
            { id: "today", label: "Bugünkü çalışmalar" },
            { id: "history", label: "Geçmiş sonuçlar" },
          ]}
        />
        <button
          className="btn secondary"
          onClick={() => {
            setInitialGoal(undefined);
            setForm("practice");
          }}
        >
          <Plus size={17} />
          Çalışma sonucu ekle
        </button>
      </div>
      <Status {...q}>
        {({ goals, results, subjects }) => (
          <>
            {view === "goals" ? (
              goals.length ? (
                <div className="cards-grid">
                  {goals.map((g) => (
                    <GoalCard
                      key={g.id}
                      goal={g}
                      results={results}
                      subjects={subjects}
                      onEdit={() => {
                        setEditing(g);
                        setForm("goal");
                      }}
                      onResult={() => {
                        setInitialGoal(g);
                        setForm("practice");
                      }}
                    />
                  ))}
                </div>
              ) : (
                <div className="paper-panel">
                  <Empty
                    icon={<Target size={34} />}
                    title="Henüz günlük hedefin yok."
                    description="Kendine uygun bir hedef seç. Her küçük adım değerli."
                    action="İlk hedefimi oluştur"
                    onAction={() => {
                      setEditing(undefined);
                      setForm("goal");
                    }}
                  />
                </div>
              )
            ) : (
              <>
                {view === "history" && (
                  <TextField
                    label="Tarihe göre filtrele"
                    type="date"
                    max={localDate()}
                    value={historyDate}
                    onChange={setHistoryDate}
                  />
                )}
                <PracticeResults
                  results={results.filter((r) =>
                    view === "today"
                      ? r.date === localDate()
                      : r.date < localDate() &&
                        (!historyDate || r.date === historyDate),
                  )}
                  subjects={subjects}
                  onAdd={() => setForm("practice")}
                />
              </>
            )}
            {form === "goal" && (
              <GoalForm
                subjects={subjects}
                existing={editing}
                onClose={() => setForm(null)}
              />
            )}{" "}
            {form === "practice" && (
              <PracticeForm
                subjects={subjects}
                goals={goals}
                initialGoal={initialGoal}
                onClose={() => setForm(null)}
              />
            )}
          </>
        )}
      </Status>
    </>
  );
}
function PracticeResults({
  results,
  subjects,
  onAdd,
}: {
  results: DailyPracticeResult[];
  subjects: Subject[];
  onAdd: () => void;
}) {
  return results.length ? (
    <div className="cards-grid">
      {results.map((r) => (
        <article className="item-card" key={r.id}>
          <Badge>
            {r.source === "extra" ? "Ekstra çalışma" : "Günlük hedef"}
          </Badge>
          <h3>{subjects.find((s) => s.id === r.subjectId)?.name || "Ders"}</h3>
          <p>
            {dateLabel(r.date)} · {r.correct + r.wrong} soru
          </p>
          <p>
            {r.correct} doğru · {r.wrong} yanlış
          </p>
        </article>
      ))}
    </div>
  ) : (
    <div className="paper-panel">
      <Empty
        title="Henüz çalışma sonucu yok."
        description="Çözdüğün soruları eklediğinde emeğini burada görebilirsin."
        action="Çalışma sonucu ekle"
        onAction={onAdd}
      />
    </div>
  );
}
