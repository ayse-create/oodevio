import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import {
  Users,
  ArrowRight,
  ArrowLeft,
  Heart,
  Check,
  MessageCircle,
  Target,
  BookX,
  ChartNoAxesCombined,
} from "lucide-react";
import { teacherService } from "../services/teacherService";
import { messageService } from "../services/messageService";
import { messagePresets } from "../models/options";
import type { MessagePreset, TeacherStudentOverview } from "../models";
import { useQuery } from "../state/AppState";
import {
  PageTitle,
  AddButton,
  Empty,
  Status,
  Modal,
  SaveForm,
  Tabs,
  Badge,
} from "../components/ui";
import { CodeField } from "../components/DomainFields";
import { isCode, localDate } from "../validation";
import { HomeworkCard } from "./HomeworkPages";
import { WrongCard } from "./WrongsPage";
import { GoalCard } from "./GoalsPage";
import { ExamAnalysis } from "../components/ExamAnalysis";
function LinkStudentForm({ onClose }: { onClose: () => void }) {
  const [code, setCode] = useState("");
  return (
    <Modal title="Öğrenci ekle" onClose={onClose}>
      <p>Öğrencinin Ayarlar sayfasındaki altı haneli kodu gir.</p>
      <SaveForm
        label="Öğrenciyi ekle"
        validate={() =>
          isCode(code) ? null : "Öğrenci kodu tam olarak altı rakam olmalı."
        }
        onSave={() => teacherService.linkStudent(code)}
        onSuccess={onClose}
      >
        <CodeField value={code} onChange={setCode} />
      </SaveForm>
    </Modal>
  );
}
export function TeacherPage() {
  const [open, setOpen] = useState(false);
  const q = useQuery(teacherService.listStudents);
  return (
    <>
      <PageTitle
        eyebrow="BİRLİKTE DAHA İLERİYE"
        title="Öğrencilerim"
        description="Her öğrencinin yolculuğuna yakından eşlik et."
        action={
          <AddButton onClick={() => setOpen(true)}>Öğrenci ekle</AddButton>
        }
      />
      <Status {...q}>
        {(students) =>
          students.length ? (
            <div className="cards-grid">
              {students.map((link) => (
                <Link
                  key={link.id}
                  className="item-card student-card"
                  to={`/ogretmen/ogrenci/${link.student.id}`}
                >
                  <div className="student-avatar">
                    <Users size={26} />
                  </div>
                  <h3>{link.student.name}</h3>
                  <p>{link.student.grade}</p>
                  <span className="text-link">
                    Çalışma defterini aç <ArrowRight size={16} />
                  </span>
                </Link>
              ))}
            </div>
          ) : (
            <div className="paper-panel">
              <Empty
                title="Henüz öğrencin yok."
                description="Öğrencinin koduyla bağlantı kur, gelişimini takip etmeye başla."
                action="Öğrenci ekle"
                onAction={() => setOpen(true)}
                icon={<Users size={34} />}
              />
              <Link className="text-link centered" to="/ogretmen/ogrenci">
                Öğrenci ayrıntısı ekranını incele <ArrowRight size={16} />
              </Link>
            </div>
          )
        }
      </Status>
      {open && <LinkStudentForm onClose={() => setOpen(false)} />}
    </>
  );
}
function Feedback({ studentId }: { studentId?: string }) {
  const [selected, setSelected] = useState<MessagePreset | null>(null);
  return (
    <section className="feedback-panel">
      <h2>
        <MessageCircle size={22} />
        Küçük bir destek gönder
      </h2>
      <p>Hazır geri bildirimlerden birini seç.</p>
      <SaveForm
        label="Geri bildirim gönder"
        disabled={!studentId}
        validate={() => (!selected ? "Bir geri bildirim seç." : null)}
        onSave={() => messageService.send(studentId!, selected!)}
      >
        <div
          className="feedback-options"
          role="group"
          aria-label="Hazır geri bildirimler"
        >
          {Object.entries(messagePresets).map(([id, label]) => (
            <button
              key={id}
              type="button"
              className={selected === id ? "selected" : ""}
              aria-pressed={selected === id}
              onClick={() => setSelected(id as MessagePreset)}
            >
              {id === "heart" ? (
                <Heart size={19} />
              ) : id === "check" ? (
                <Check size={19} />
              ) : null}
              {label}
            </button>
          ))}
        </div>
        {!studentId && (
          <p className="helper">
            Geri bildirim göndermek için önce bir öğrenci seç.
          </p>
        )}
      </SaveForm>
    </section>
  );
}
function TeacherSummary({ data }: { data: TeacherStudentOverview | null }) {
  const s = data?.summary;
  return (
    <>
      <div className="teacher-stats">
        {[
          { label: "Bugün çözülen soru", value: s?.totalQuestions ?? 0 },
          { label: "Doğru", value: s?.correct ?? 0 },
          { label: "Yanlış", value: s?.wrong ?? 0 },
          { label: "Günlük hedef", value: s?.target ?? 0 },
          { label: "Tamamlanan ödev", value: s?.completedHomework ?? 0 },
        ].map((x) => (
          <div key={x.label}>
            <strong>{x.value}</strong>
            <span>{x.label}</span>
          </div>
        ))}
      </div>
      <section className="settings-section">
        <h2>Günlük hedef ilerlemesi</h2>
        <progress
          value={s?.target ? Math.min(s.totalQuestions, s.target) : 0}
          max={s?.target || 100}
          aria-label="Öğrencinin günlük hedef ilerlemesi"
        />
        <p className="helper">
          {s?.target
            ? `${s.totalQuestions} / ${s.target} soru`
            : "Henüz günlük hedef yok."}
        </p>
      </section>
      {!data && (
        <Empty
          title="Henüz bir öğrenci seçilmedi."
          description="Bir öğrenciyi ekledikten sonra çalışma özeti burada görünecek."
          icon={<Users size={30} />}
          action="Öğrencilerime git"
          to="/ogretmen"
        />
      )}
    </>
  );
}
export function TeacherStudentPage() {
  const { id } = useParams();
  const [tab, setTab] = useState("summary");
  const q = useQuery(
    () => (id ? teacherService.getStudent(id) : Promise.resolve(null)),
    [id],
  );
  return (
    <>
      <Link className="back-link" to="/ogretmen">
        <ArrowLeft size={16} />
        Öğrencilerime dön
      </Link>
      <Status {...q}>
        {(d) => (
          <>
            <PageTitle
              eyebrow="ÖĞRENCİ ÇALIŞMA DEFTERİ"
              title={d?.student.name || "Öğrenci görünümü"}
              description={
                d?.student.grade ||
                "Öğrencinin çalışma yolculuğu bu sayfada bir araya gelir."
              }
            />
            <Tabs
              value={tab}
              onChange={setTab}
              items={[
                { id: "summary", label: "Genel özet" },
                { id: "homework", label: "Ödevler" },
                { id: "today", label: "Bugün tamamlananlar" },
                { id: "goals", label: "Günlük hedefler" },
                { id: "wrongs", label: "Yanlış Defteri" },
                { id: "exams", label: "Deneme gelişimi" },
              ]}
            />
            {tab === "summary" && <TeacherSummary data={d} />}{" "}
            {(tab === "homework" || tab === "today") &&
              (() => {
                const ids = new Set(
                  (d?.completions || [])
                    .filter(
                      (c) => localDate(new Date(c.completedAt)) === localDate(),
                    )
                    .map((c) => c.homeworkId),
                );
                const list = (d?.homework || []).filter(
                  (h) => tab === "homework" || ids.has(h.id),
                );
                return list.length ? (
                  <div className="cards-grid">
                    {list.map((h) => (
                      <HomeworkCard
                        key={h.id}
                        homework={h}
                        subjects={d!.subjects}
                        readOnly
                      />
                    ))}
                  </div>
                ) : (
                  <div className="paper-panel">
                    <Empty
                      title={
                        tab === "today"
                          ? "Bugün tamamlanan ödev yok."
                          : "Henüz ödev yok."
                      }
                      description="Öğrencinin ödevleri eklendiğinde burada görünecek."
                    />
                  </div>
                );
              })()}
            {tab === "goals" &&
              (d?.goals.length ? (
                <div className="cards-grid">
                  {d.goals.map((g) => (
                    <GoalCard
                      key={g.id}
                      goal={g}
                      results={d.practices}
                      subjects={d.subjects}
                    />
                  ))}
                </div>
              ) : (
                <div className="paper-panel">
                  <Empty
                    title="Henüz günlük hedef yok."
                    description="Öğrencinin hedefleri ve gerçekleşme durumu burada görünecek."
                    icon={<Target size={32} />}
                  />
                </div>
              ))}
            {tab === "wrongs" &&
              (d?.wrongEntries.length ? (
                <div className="squared-paper cards-grid">
                  {d.wrongEntries.map((w) => (
                    <WrongCard key={w.id} entry={w} subjects={d.subjects} />
                  ))}
                </div>
              ) : (
                <div className="squared-paper">
                  <Empty
                    title="Henüz yanlış kaydı yok."
                    description="Çalışılması gereken konular burada bir araya gelecek."
                    icon={<BookX size={32} />}
                  />
                </div>
              ))}
            {tab === "exams" && (
              <ExamAnalysis
                exams={d?.mockExams || []}
                subjects={d?.subjects || []}
              />
            )}
            <Feedback studentId={d?.student.id} />
          </>
        )}
      </Status>
    </>
  );
}
