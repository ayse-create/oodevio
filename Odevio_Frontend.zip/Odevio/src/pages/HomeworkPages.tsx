import { useState } from "react";
import { Link, useParams, useSearchParams } from "react-router-dom";
import {
  BookOpen,
  CalendarDays,
  CheckCircle2,
  ArrowLeft,
  ArrowRight,
  MessageSquare,
} from "lucide-react";
import {
  PageTitle,
  AddButton,
  Empty,
  Status,
  Modal,
  SaveForm,
  TextField,
  TextArea,
  Tabs,
  Badge,
} from "../components/ui";
import { SubjectSelect, WrongTopics } from "../components/DomainFields";
import { homeworkService } from "../services/homeworkService";
import { subjectService } from "../services/subjectService";
import { useQuery } from "../state/AppState";
import type { Homework, Subject, WrongTopic } from "../models";
import { localDate, dateLabel, validateResults } from "../validation";
export function HomeworkForm({
  subjects,
  existing,
  onClose,
}: {
  subjects: Subject[];
  existing?: Homework;
  onClose: () => void;
}) {
  const [subject, setSubject] = useState(existing?.subjectId || "");
  const [description, setDescription] = useState(existing?.description || "");
  const [assigned, setAssigned] = useState(
    existing?.assignedDate || localDate(),
  );
  const [due, setDue] = useState(existing?.dueDate || "");
  const [total, setTotal] = useState<number | string>(
    existing?.totalQuestions ?? "",
  );
  const [note, setNote] = useState(existing?.teacherNote || "");
  return (
    <Modal
      title={existing ? "Ödevi düzenle" : "Yeni ödev ekle"}
      onClose={onClose}
    >
      <SaveForm
        onSuccess={onClose}
        validate={() =>
          !description.trim()
            ? "Ödev açıklamasını yaz."
            : due < assigned
              ? "Son teslim tarihi veriliş tarihinden önce olamaz."
              : Number(total) < 1
                ? "En az bir soru gir."
                : null
        }
        onSave={() => {
          const input = {
            subjectId: subject,
            description: description.trim(),
            assignedDate: assigned,
            dueDate: due,
            totalQuestions: Number(total),
            teacherNote: note,
          };
          return existing
            ? homeworkService.update(existing.id, input)
            : homeworkService.create(input);
        }}
      >
        <SubjectSelect
          subjects={subjects}
          value={subject}
          onChange={setSubject}
        />
        {!subjects.length && (
          <p className="helper">
            Derslerini seçmek için Ayarlar sayfasını kullanabilirsin. Dersler
            bağlantı kurulduğunda yüklenir.
          </p>
        )}
        <TextArea
          label="Ödev başlığı / açıklaması"
          required
          value={description}
          onChange={setDescription}
        />
        <div className="form-grid">
          <TextField
            label="Veriliş tarihi"
            type="date"
            required
            value={assigned}
            onChange={setAssigned}
          />
          <TextField
            label="Son teslim tarihi"
            type="date"
            required
            min={assigned}
            value={due}
            onChange={setDue}
          />
        </div>
        <TextField
          label="Toplam soru sayısı"
          type="number"
          min={1}
          step={1}
          required
          value={total}
          onChange={setTotal}
        />
        <TextArea
          label="Öğretmen notu (isteğe bağlı)"
          value={note}
          onChange={setNote}
        />
      </SaveForm>
    </Modal>
  );
}
export function HomeworkCard({
  homework: h,
  subjects,
  readOnly = false,
}: {
  homework: Homework;
  subjects: Subject[];
  readOnly?: boolean;
}) {
  return (
    <article className="item-card homework-card">
      <div className="item-top">
        <Badge>
          {subjects.find((s) => s.id === h.subjectId)?.name || "Ders"}
        </Badge>
        <Badge tone={h.status === "completed" ? "green" : ""}>
          {h.status === "completed" ? "Tamamlandı" : "Bekliyor"}
        </Badge>
      </div>
      <h3>{h.description}</h3>
      <div className="metadata">
        <span>
          <CalendarDays size={15} />
          Veriliş: {dateLabel(h.assignedDate)}
        </span>
        <span>Son teslim: {dateLabel(h.dueDate)}</span>
        <span>{h.totalQuestions} soru</span>
      </div>
      {h.teacherNote && (
        <p className="teacher-note">
          <MessageSquare size={16} />
          {h.teacherNote}
        </p>
      )}
      {!readOnly && (
        <Link className="text-link" to={`/ogrenci/odevler/${h.id}`}>
          Ödevi aç <ArrowRight size={16} />
        </Link>
      )}
    </article>
  );
}
export function HomeworkPage() {
  const [params, setParams] = useSearchParams();
  const [filter, setFilter] = useState("all");
  const q = useQuery(async () => {
    const [homework, subjects] = await Promise.all([
      homeworkService.list(),
      subjectService.listSelected(),
    ]);
    return { homework, subjects };
  });
  const open = params.get("yeni") === "1";
  return (
    <>
      <PageTitle
        eyebrow="ÇALIŞMA SAYFALARI"
        title="Ödevlerim"
        description="Her ders için bir yer, her ödev için bir adım."
        action={
          <AddButton onClick={() => setParams({ yeni: "1" })}>
            Yeni ödev
          </AddButton>
        }
      />
      <Status {...q}>
        {({ homework, subjects }) => (
          <>
            <Tabs
              value={filter}
              onChange={setFilter}
              items={[
                { id: "all", label: "Bütün dersler" },
                ...subjects.map((s) => ({ id: s.id, label: s.name })),
              ]}
            />
            {homework.filter((h) => filter === "all" || h.subjectId === filter)
              .length ? (
              <div className="cards-grid">
                {homework
                  .filter((h) => filter === "all" || h.subjectId === filter)
                  .map((h) => (
                    <HomeworkCard key={h.id} homework={h} subjects={subjects} />
                  ))}
              </div>
            ) : (
              <div className="paper-panel">
                <Empty
                  title="Henüz ödevin yok."
                  description="Ödevlerini derslerine göre düzenle, birer birer tamamla."
                  action="Yeni ödev ekle"
                  onAction={() => setParams({ yeni: "1" })}
                />
              </div>
            )}
            {open && (
              <HomeworkForm subjects={subjects} onClose={() => setParams({})} />
            )}
          </>
        )}
      </Status>
    </>
  );
}
export function CompletionForm({
  homework,
  onClose,
}: {
  homework: Homework;
  onClose: () => void;
}) {
  const [correct, setCorrect] = useState("");
  const [wrong, setWrong] = useState("");
  const [topics, setTopics] = useState<WrongTopic[]>([]);
  return (
    <Modal title="Ödevini değerlendir" onClose={onClose}>
      <div className="completion-heading">
        <CheckCircle2 size={26} />
        <div>
          <strong>{homework.description}</strong>
          <p>{homework.totalQuestions} sorunun sonucunu gir.</p>
        </div>
      </div>
      <SaveForm
        label="Değerlendir ve tamamla"
        validate={() =>
          validateResults(
            Number(correct),
            Number(wrong),
            topics,
            homework.totalQuestions,
          )
        }
        onSave={() =>
          homeworkService.complete(homework.id, {
            correct: Number(correct),
            wrong: Number(wrong),
            wrongTopics: Number(wrong) > 0 ? topics : [],
          })
        }
        onSuccess={onClose}
      >
        <div className="form-grid">
          <TextField
            label="Doğru sayısı"
            type="number"
            min={0}
            step={1}
            value={correct}
            onChange={setCorrect}
            required
          />
          <TextField
            label="Yanlış sayısı"
            type="number"
            min={0}
            step={1}
            value={wrong}
            onChange={setWrong}
            required
          />
        </div>
        <WrongTopics
          value={topics}
          onChange={setTopics}
          wrong={Number(wrong)}
        />
        <p className="helper">
          Yanlışların kaydedildiğinde Yanlış Defteri’ne aktarılacak.
        </p>
      </SaveForm>
    </Modal>
  );
}
export function HomeworkDetail() {
  const { id = "" } = useParams();
  const [complete, setComplete] = useState(false);
  const [edit, setEdit] = useState(false);
  const q = useQuery(async () => {
    const [homework, subjects] = await Promise.all([
      homeworkService.get(id),
      subjectService.listSelected(),
    ]);
    return { homework, subjects };
  }, [id]);
  return (
    <>
      <Link to="/ogrenci/odevler" className="back-link">
        <ArrowLeft size={16} />
        Ödevlerime dön
      </Link>
      <PageTitle title="Ödev ayrıntıları" />
      <Status {...q}>
        {({ homework: h, subjects }) =>
          h ? (
            <>
              <HomeworkCard homework={h} subjects={subjects} readOnly />
              {h.status !== "completed" && (
                <div className="action-row">
                  <button className="btn" onClick={() => setComplete(true)}>
                    <CheckCircle2 size={18} />
                    Ödevi tamamla
                  </button>
                  <button
                    className="btn secondary"
                    onClick={() => setEdit(true)}
                  >
                    Düzenle
                  </button>
                </div>
              )}
              {complete && (
                <CompletionForm
                  homework={h}
                  onClose={() => setComplete(false)}
                />
              )}{" "}
              {edit && (
                <HomeworkForm
                  existing={h}
                  subjects={subjects}
                  onClose={() => setEdit(false)}
                />
              )}
            </>
          ) : (
            <Empty
              title="Bu ödev bulunamadı."
              description="Henüz bir ödev seçilmedi veya bu ödev artık erişilebilir değil."
              action="Ödevlerime dön"
              to="/ogrenci/odevler"
            />
          )
        }
      </Status>
    </>
  );
}
