import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  ArrowRight,
  BookOpen,
  GraduationCap,
  ArrowLeft,
  Sparkles,
  Check,
} from "lucide-react";
import { ThemePicker } from "../theme/ThemeProvider";
import { SaveForm, TextField, PageTitle, Field } from "../components/ui";
import { CodeField, SubjectPicker } from "../components/DomainFields";
import { authService } from "../services/authService";
import { useApp } from "../state/AppState";
import { isCode } from "../validation";
export function CoverPage() {
  const [opening, setOpening] = useState(false);
  const navigate = useNavigate();
  function open() {
    if (opening) return;
    setOpening(true);
    setTimeout(
      () => navigate("/giris"),
      window.matchMedia("(prefers-reduced-motion: reduce)").matches ? 0 : 650,
    );
  }
  return (
    <div className="cover-scene">
      <div className="cover-top">
        <span className="wordmark">ödevio ✳</span>
        <span>Senin çalışma defterin.</span>
      </div>
      <div className="cover-stage">
        <button
          className={`notebook-cover ${opening ? "opening" : ""}`}
          onClick={open}
          aria-label="Ödevio defterini aç"
        >
          <span className="cover-spine" />
          <span className="cover-edition">HER GÜN YENİ BİR SAYFA</span>
          <span className="cover-label">
            <span className="cover-small">BU DEFTER SANA AİT</span>
            <span className="cover-name">
              Ödevio<span>✳</span>
            </span>
            <span className="cover-rule" />
            <span className="cover-subtitle">
              Hayallerin, hedeflerin
              <br />
              ve küçük büyük başarıların.
            </span>
          </span>
          <span className="cover-open-label">
            Defterini aç <ArrowRight size={19} />
          </span>
          <span className="cover-number">ÇALIŞMA DEFTERİ · 01</span>
          <span className="elastic" />
        </button>
      </div>
      <div className="cover-bottom">
        <span>
          <BookOpen size={17} />
          Kaldığın yerden, kendi hızında.
        </span>
        <ThemePicker />
      </div>
    </div>
  );
}
export function RolePage() {
  return (
    <div className="entry-page page-turn">
      <Link to="/" className="back-link">
        <ArrowLeft size={18} />
        Kapağa dön
      </Link>
      <div className="entry-sheet">
        <div className="wordmark">ödevio ✳</div>
        <span className="eyebrow">İLK SAYFA</span>
        <h1>Defterine hoş geldin.</h1>
        <p>Başlamak için kendi sayfanı seç.</p>
        <div className="role-cards">
          <Link to="/giris/ogrenci" className="role-card">
            <span className="role-icon">
              <BookOpen size={34} />
            </span>
            <h2>Öğrenci Girişi</h2>
            <p>
              Ödevlerin, hedeflerin ve ilerlemen
              <br />
              aynı defterde.
            </p>
            <span className="role-cta">
              Öğrenci sayfasını aç <ArrowRight size={18} />
            </span>
          </Link>
          <Link to="/giris/ogretmen" className="role-card teacher">
            <span className="role-icon">
              <GraduationCap size={36} />
            </span>
            <h2>Öğretmen Girişi</h2>
            <p>
              Öğrencilerinin yolculuğunu takip et,
              <br />
              gelişimlerine destek ol.
            </p>
            <span className="role-cta">
              Öğretmen sayfasını aç <ArrowRight size={18} />
            </span>
          </Link>
        </div>
        <div className="inspect-links">
          <span>Önce bir göz atmak ister misin?</span>
          <Link to="/ogrenci">
            Öğrenci ekranlarını incele <ArrowRight size={15} />
          </Link>
          <Link to="/ogretmen">
            Öğretmen ekranlarını incele <ArrowRight size={15} />
          </Link>
        </div>
      </div>
    </div>
  );
}
export function StudentEntry() {
  return (
    <div className="entry-page page-turn">
      <Link to="/giris" className="back-link">
        <ArrowLeft size={18} />
        Geri
      </Link>
      <div className="entry-sheet narrow">
        <BookOpen className="entry-icon" size={36} />
        <h1>
          Senin defterin,
          <br />
          senin yolculuğun.
        </h1>
        <p>Başlamaya hazır mısın?</p>
        <Link className="btn large" to="/kayit">
          Yeni hesap oluştur <ArrowRight size={18} />
        </Link>
        <Link className="btn secondary large" to="/giris/ogrenci/kod">
          Zaten hesabım var
        </Link>
        <Link className="text-link" to="/ogrenci">
          Hesapsız incele
        </Link>
      </div>
    </div>
  );
}
export function LoginPage({ teacher = false }: { teacher?: boolean }) {
  const [code, setCode] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { setSession } = useApp();
  const navigate = useNavigate();
  return (
    <div className="entry-page page-turn">
      <Link to="/giris" className="back-link">
        <ArrowLeft size={18} />
        Geri
      </Link>
      <div className="entry-sheet narrow">
        <span className="eyebrow">
          {teacher ? "ÖĞRETMEN" : "ÖĞRENCİ"} GİRİŞİ
        </span>
        <h1>Yeniden merhaba.</h1>
        <p>
          {teacher
            ? "Öğretmen hesabınla devam et."
            : "Defterini açmak için öğrenci kodunu gir."}
        </p>
        <SaveForm
          label="Giriş yap"
          validate={() =>
            !teacher && !isCode(code)
              ? "Öğrenci kodu tam olarak altı rakam olmalı."
              : null
          }
          onSave={async () => {
            const s = teacher
              ? await authService.loginTeacher(email, password)
              : await authService.loginStudent(code);
            setSession(s);
            navigate(teacher ? "/ogretmen" : "/ogrenci");
          }}
        >
          {teacher ? (
            <>
              <TextField
                label="E-posta"
                type="email"
                required
                value={email}
                onChange={setEmail}
                autoComplete="username"
              />
              <TextField
                label="Şifre"
                type="password"
                required
                value={password}
                onChange={setPassword}
                autoComplete="current-password"
              />
            </>
          ) : (
            <CodeField value={code} onChange={setCode} />
          )}
        </SaveForm>
        <Link className="text-link" to={teacher ? "/ogretmen" : "/ogrenci"}>
          Hesapsız ekranları incele
        </Link>
      </div>
    </div>
  );
}
export function RegisterPage() {
  const [name, setName] = useState("");
  const [grade, setGrade] = useState("");
  const [school, setSchool] = useState("");
  const [avatar, setAvatar] = useState<string | null>(null);
  const [subjects, setSubjects] = useState<string[]>([]);
  const navigate = useNavigate();
  const { setSession } = useApp();
  return (
    <div className="entry-page page-turn">
      <Link to="/giris/ogrenci" className="back-link">
        <ArrowLeft size={18} />
        Geri
      </Link>
      <div className="entry-sheet form-sheet">
        <PageTitle
          eyebrow="YENİ BİR BAŞLANGIÇ"
          title="Defterini kendine ait yap."
        />
        <SaveForm
          label="Hesap oluştur"
          validate={() =>
            !name.trim()
              ? "İsmini yaz."
              : !subjects.length
                ? "En az bir ders seçmelisin."
                : null
          }
          onSave={async () => {
            const s = await authService.registerStudent({
              name: name.trim(),
              grade,
              school,
              avatar,
              subjectIds: subjects,
            });
            setSession(s);
            navigate("/ogrenci");
          }}
        >
          <TextField
            label="İsim"
            value={name}
            onChange={setName}
            required
            autoComplete="given-name"
          />
          <div className="form-grid">
            <TextField
              label="Sınıf"
              value={grade}
              onChange={setGrade}
              required
            />
            <TextField
              label="Okul (isteğe bağlı)"
              value={school}
              onChange={setSchool}
            />
          </div>
          <fieldset>
            <legend>Avatarını seç</legend>
            <div className="avatar-options">
              {["flower", "star", "book", "heart", "sun"].map((a, i) => (
                <button
                  key={a}
                  type="button"
                  aria-label={
                    [
                      "Çiçek avatarı",
                      "Yıldız avatarı",
                      "Kitap avatarı",
                      "Kalp avatarı",
                      "Güneş avatarı",
                    ][i]
                  }
                  aria-pressed={avatar === a}
                  className={avatar === a ? "selected" : ""}
                  onClick={() => setAvatar(a)}
                >
                  {["✿", "★", "▤", "♡", "☀"][i]}
                </button>
              ))}
            </div>
          </fieldset>
          <SubjectPicker selected={subjects} onChange={setSubjects} />
          <div className="code-placeholder">
            <span>Öğrenci kodun</span>
            <strong>------</strong>
            <small>Kod backend tarafından oluşturulacak.</small>
          </div>
        </SaveForm>
      </div>
    </div>
  );
}
