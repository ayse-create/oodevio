import { useState } from "react";
import { BookX, CheckCircle2, History } from "lucide-react";
import type { StudyMethod, WrongEntry, Subject } from "../models";
import { wrongNotebookService } from "../services/wrongNotebookService";
import { subjectService } from "../services/subjectService";
import { studyMethods, sourceLabels } from "../models/options";
import { useQuery } from "../state/AppState";
import {
  Empty,
  Status,
  PageTitle,
  Tabs,
  Badge,
  Modal,
  SaveForm,
} from "../components/ui";
import { dateLabel } from "../validation";
export function WrongCard({
  entry: w,
  subjects,
  onStudy,
}: {
  entry: WrongEntry;
  subjects: Subject[];
  onStudy?: (w: WrongEntry) => void;
}) {
  return (
    <article className="item-card wrong-card">
      <div className="item-top">
        <Badge>
          {subjects.find((s) => s.id === w.subjectId)?.name || "Ders"}
        </Badge>
        <span className="metadata">{dateLabel(w.date)}</span>
      </div>
      <h3>{w.topic}</h3>
      <p>
        {w.wrongCount} yanlış · {sourceLabels[w.source]}
      </p>
      <div className="tags">
        <Badge tone={w.studied ? "green" : ""}>
          {w.studied ? "Çalışıldı" : "Çalışılacak"}
        </Badge>
        {w.studyMethods.map((m) => (
          <Badge key={m}>{studyMethods[m]}</Badge>
        ))}
      </div>
      {onStudy && (
        <button className="btn secondary small" onClick={() => onStudy(w)}>
          <CheckCircle2 size={16} />
          {w.studied ? "Çalışma yöntemlerini düzenle" : "Bu konuya çalıştım"}
        </button>
      )}
    </article>
  );
}
function StudyModal({
  entry,
  onClose,
}: {
  entry: WrongEntry;
  onClose: () => void;
}) {
  const [selected, setSelected] = useState<StudyMethod[]>(entry.studyMethods);
  return (
    <Modal title="Bu konuya nasıl çalıştın?" onClose={onClose}>
      <p>{entry.topic}</p>
      <SaveForm
        onSave={() => wrongNotebookService.markStudied(entry.id, selected)}
        onSuccess={onClose}
      >
        <div className="checks stacked">
          {Object.entries(studyMethods).map(([key, label]) => (
            <label key={key}>
              <input
                type="checkbox"
                checked={selected.includes(key as StudyMethod)}
                onChange={(e) =>
                  setSelected(
                    e.target.checked
                      ? [...selected, key as StudyMethod]
                      : selected.filter((m) => m !== key),
                  )
                }
              />
              {label}
            </label>
          ))}
        </div>
        <p className="helper">
          Birden fazla yöntem seçebilirsin. Seçimleri kaldırırsan konu yeniden
          “Çalışılacak” olur.
        </p>
      </SaveForm>
    </Modal>
  );
}
export function WrongsPage() {
  const [view, setView] = useState<"current" | "history">("current");
  const [selected, setSelected] = useState<WrongEntry | null>(null);
  const q = useQuery(async () => {
    const [entries, subjects] = await Promise.all([
      wrongNotebookService.list(view),
      subjectService.listSelected(),
    ]);
    return { entries, subjects };
  }, [view]);
  return (
    <>
      <PageTitle
        eyebrow="YANLIŞLARDAN ÖĞREN"
        title="Yanlış Defteri"
        description="Bir yanlış, öğrenmek için yeni bir fırsat."
      />
      <Tabs
        value={view}
        onChange={(v) => setView(v as typeof view)}
        items={[
          { id: "current", label: "Güncel yanlışlar" },
          { id: "history", label: "Geçmiş" },
        ]}
      />
      <div className="squared-paper">
        <Status {...q}>
          {({ entries, subjects }) =>
            entries.length ? (
              <div className="cards-grid">
                {entries.map((w) => (
                  <WrongCard
                    key={w.id}
                    entry={w}
                    subjects={subjects}
                    onStudy={setSelected}
                  />
                ))}
              </div>
            ) : (
              <Empty
                title={
                  view === "current"
                    ? "Henüz yanlış kaydın yok."
                    : "Geçmişte yanlış kaydın yok."
                }
                description={
                  view === "current"
                    ? "Ödev, günlük çalışma ve deneme yanlışlarını burada birlikte çalışacağız."
                    : "Bir ayı geçen yanlışlar silinmeden bu sayfada saklanacak."
                }
                icon={
                  view === "current" ? (
                    <BookX size={32} strokeWidth={1.4} />
                  ) : (
                    <History size={32} />
                  )
                }
                action={view === "current" ? "Ödevlerime git" : undefined}
                to="/ogrenci/odevler"
              />
            )
          }
        </Status>
      </div>
      <p className="page-hint">
        Güncel kayıtlar bir ay sonra Geçmiş’e taşınır; öğrendiklerin kaybolmaz.
      </p>
      {selected && (
        <StudyModal entry={selected} onClose={() => setSelected(null)} />
      )}
    </>
  );
}
