import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Palette, UserRound, LogOut, Trash2, ShieldAlert } from "lucide-react";
import { ThemePicker } from "../theme/ThemeProvider";
import {
  PageTitle,
  Status,
  SaveForm,
  TextField,
  Modal,
} from "../components/ui";
import { SubjectPicker } from "../components/DomainFields";
import { studentService } from "../services/studentService";
import { teacherService } from "../services/teacherService";
import { subjectService } from "../services/subjectService";
import { authService } from "../services/authService";
import { useQuery, useApp } from "../state/AppState";
import type { StudentProfile, TeacherProfile } from "../models";
function StudentProfileForm({ profile }: { profile: StudentProfile | null }) {
  const [name, setName] = useState(profile?.name || "");
  const [grade, setGrade] = useState(profile?.grade || "");
  const [school, setSchool] = useState(profile?.school || "");
  const [selected, setSelected] = useState(profile?.subjectIds || []);
  return (
    <SaveForm
      label="Profilimi güncelle"
      validate={() =>
        !name.trim()
          ? "İsmini yaz."
          : !selected.length
            ? "En az bir ders seç."
            : null
      }
      onSave={() =>
        studentService.updateProfile({
          name: name.trim(),
          grade,
          school,
          subjectIds: selected,
        })
      }
    >
      <TextField label="İsim" required value={name} onChange={setName} />
      <div className="form-grid">
        <TextField label="Sınıf" required value={grade} onChange={setGrade} />
        <TextField
          label="Okul (isteğe bağlı)"
          value={school}
          onChange={setSchool}
        />
      </div>
      <SubjectPicker selected={selected} onChange={setSelected} />
      <div className="code-placeholder">
        <span>Altı haneli öğrenci kodun</span>
        <strong>{profile?.studentCode || "------"}</strong>
        <small>
          {profile?.studentCode
            ? "Öğretmeninle bağlantı kurmak için bu kodu paylaşabilirsin."
            : "Kod backend tarafından oluşturulacak."}
        </small>
      </div>
    </SaveForm>
  );
}
function TeacherProfileForm({ profile }: { profile: TeacherProfile | null }) {
  const [name, setName] = useState(profile?.name || "");
  const [email, setEmail] = useState(profile?.email || "");
  const [branch, setBranch] = useState(profile?.branch || "");
  return (
    <SaveForm
      label="Profilimi güncelle"
      validate={() => (!name.trim() ? "İsmini yaz." : null)}
      onSave={() =>
        teacherService.updateProfile({ name: name.trim(), email, branch })
      }
    >
      <TextField label="İsim" required value={name} onChange={setName} />
      <TextField
        label="E-posta"
        required
        type="email"
        value={email}
        onChange={setEmail}
      />
      <TextField label="Branş" value={branch} onChange={setBranch} />
    </SaveForm>
  );
}
export function SettingsPage({ teacher = false }: { teacher?: boolean }) {
  const [action, setAction] = useState<"logout" | "delete" | null>(null);
  const [confirmation, setConfirmation] = useState("");
  const navigate = useNavigate();
  const { setSession } = useApp();
  const q = useQuery<StudentProfile | TeacherProfile | null>(
    () => (teacher ? teacherService.getProfile() : studentService.getProfile()),
    [teacher],
  );
  return (
    <>
      <PageTitle
        eyebrow="DEFTERİNİ KİŞİSELLEŞTİR"
        title="Ayarlar"
        description="Kendi rengin, kendi düzenin."
      />
      <section className="settings-section">
        <h2>
          <Palette size={21} />
          Defter rengi
        </h2>
        <p>Sana en iyi gelen rengi seç.</p>
        <ThemePicker />
      </section>
      <section className="settings-section">
        <h2>
          <UserRound size={21} />
          Profil bilgileri
        </h2>
        <Status {...q}>
          {(p) =>
            teacher ? (
              <TeacherProfileForm profile={p as TeacherProfile | null} />
            ) : (
              <StudentProfileForm profile={p as StudentProfile | null} />
            )
          }
        </Status>
      </section>
      <section className="settings-section account-actions">
        <h2>Hesap işlemleri</h2>
        <button className="btn secondary" onClick={() => setAction("logout")}>
          <LogOut size={18} />
          Hesaptan çık
        </button>
        <button
          className="btn secondary danger"
          onClick={() => {
            setConfirmation("");
            setAction("delete");
          }}
        >
          <Trash2 size={18} />
          Hesabı sil
        </button>
      </section>
      {action === "logout" && (
        <Modal title="Hesabından çıkılsın mı?" onClose={() => setAction(null)}>
          <SaveForm
            label="Hesaptan çık"
            onSave={async () => {
              await authService.logout();
              setSession(null);
              navigate("/giris");
            }}
          >
            <p>
              Kaydedilmemiş form bilgilerin bu sayfadan ayrıldığında
              kaybolabilir.
            </p>
          </SaveForm>
        </Modal>
      )}
      {action === "delete" && (
        <Modal
          title="Hesabını kalıcı olarak sil"
          onClose={() => setAction(null)}
          danger
        >
          <ShieldAlert size={36} className="danger-text" />
          <p>
            Hesabın ve ona bağlı bütün kayıtların kalıcı olarak silinecek. Bu
            işlem geri alınamaz.
          </p>
          <SaveForm
            label="Hesabımı kalıcı olarak sil"
            validate={() =>
              confirmation !== "SİL" ? "Devam etmek için SİL yazmalısın." : null
            }
            onSave={async () => {
              await authService.deleteAccount();
              setSession(null);
              navigate("/");
            }}
          >
            <TextField
              label="Onaylamak için SİL yaz"
              required
              value={confirmation}
              onChange={setConfirmation}
            />
            <button
              type="button"
              className="btn secondary"
              onClick={() => setAction(null)}
            >
              Vazgeç, hesabımı koru
            </button>
          </SaveForm>
        </Modal>
      )}
    </>
  );
}
