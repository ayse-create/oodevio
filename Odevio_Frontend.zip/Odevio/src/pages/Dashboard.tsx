import { Link } from "react-router-dom";
import { ArrowUpRight, CalendarDays, Sparkles } from "lucide-react";
import { useQuery } from "../state/AppState";
import { studentService } from "../services/studentService";
import { homeworkService } from "../services/homeworkService";
import { subjectService } from "../services/subjectService";
import { messageService } from "../services/messageService";
import { Status, PageTitle } from "../components/ui";
import {
  CalendarLeaf,
  Clock,
  MessageCard,
  HomeworkSummary,
  SummaryCard,
} from "../components/DashboardCards";
import { localDate } from "../validation";
export function Dashboard() {
  const q = useQuery(async () => {
    const [profile, summary, homework, subjects, messages] = await Promise.all([
      studentService.getProfile(),
      studentService.getDailySummary(localDate()),
      homeworkService.list(),
      subjectService.listSelected(),
      messageService.listReceived(),
    ]);
    return { profile, summary, homework, subjects, messages };
  });
  return (
    <Status {...q}>
      {(d) => (
        <>
          <PageTitle
            eyebrow={new Date()
              .toLocaleDateString("tr-TR", {
                day: "numeric",
                month: "long",
                year: "numeric",
                weekday: "long",
              })
              .toLocaleUpperCase("tr-TR")}
            title={
              d.profile
                ? `Merhaba, ${d.profile.name}.`
                : "Bugün, yeni bir sayfa."
            }
            description="Küçük adımlar, güzel ilerlemeler."
            action={
              <span className="today-stamp">
                <Sparkles size={17} />
                Kendi hızında ilerle
              </span>
            }
          />
          <div className="dashboard-top">
            <CalendarLeaf />
            <Clock />
            <MessageCard messages={d.messages} />
          </div>
          <div className="dashboard-bottom">
            <HomeworkSummary homework={d.homework} subjects={d.subjects} />
            <SummaryCard summary={d.summary} />
          </div>
          <Link to="/ogrenci/plan" className="plan-strip">
            <span className="strip-icon">
              <CalendarDays size={23} />
            </span>
            <div>
              <strong>Haftana biraz yer aç.</strong>
              <span>Çalışma zamanlarını kendi ritmine göre planla.</span>
            </div>
            <ArrowUpRight size={23} />
          </Link>
        </>
      )}
    </Status>
  );
}
