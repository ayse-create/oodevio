import { useState } from "react";
import {
  StickyNote,
  LockKeyhole,
  Search,
  Pin,
  Trash2,
  Pencil,
} from "lucide-react";
import type { PrivateNote, Subject } from "../models";
import { noteService } from "../services/noteService";
import { subjectService } from "../services/subjectService";
import { useQuery, useApp } from "../state/AppState";
import {
  PageTitle,
  AddButton,
  Empty,
  Status,
  Modal,
  SaveForm,
  TextField,
  TextArea,
  SelectField,
  Confirm,
  Badge,
  Field,
} from "../components/ui";
function NoteForm({
  existing,
  subjects,
  onClose,
}: {
  existing?: PrivateNote;
  subjects: Subject[];
  onClose: () => void;
}) {
  const [title, setTitle] = useState(existing?.title || "");
  const [content, setContent] = useState(existing?.content || "");
  const [subjectId, setSubject] = useState(existing?.subjectId || "");
  const [pinned, setPinned] = useState(existing?.pinned || false);
  return (
    <Modal
      title={existing ? "Notunu düzenle" : "Yeni özel not"}
      onClose={onClose}
    >
      <SaveForm
        validate={() =>
          !title.trim() || !content.trim()
            ? "Not başlığı ve içeriği boş olamaz."
            : null
        }
        onSuccess={onClose}
        onSave={() => {
          const input = {
            title: title.trim(),
            content: content.trim(),
            subjectId: subjectId || null,
            pinned,
          };
          return existing
            ? noteService.update(existing.id, input)
            : noteService.create(input);
        }}
      >
        <TextField
          label="Not başlığı"
          required
          value={title}
          onChange={setTitle}
        />
        <SelectField
          label="Ders (isteğe bağlı)"
          empty="Kişisel not"
          value={subjectId}
          onChange={setSubject}
          options={subjects.map((s) => ({ value: s.id, label: s.name }))}
        />
        <TextArea
          label="Notun"
          required
          value={content}
          onChange={setContent}
        />
        <label className="check-label">
          <input
            type="checkbox"
            checked={pinned}
            onChange={(e) => setPinned(e.target.checked)}
          />
          Bu notu sabitle
        </label>
        <p className="privacy-hint">
          <LockKeyhole size={16} />
          Bu sayfa yalnızca sana ait.
        </p>
      </SaveForm>
    </Modal>
  );
}
export function NotesPage() {
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");
  const [form, setForm] = useState<{ note?: PrivateNote } | null>(null);
  const [deleting, setDeleting] = useState<PrivateNote | null>(null);
  const [pinning, setPinning] = useState<PrivateNote | null>(null);
  const q = useQuery(async () => {
    const [notes, subjects] = await Promise.all([
      noteService.list(),
      subjectService.listSelected(),
    ]);
    return { notes, subjects };
  });
  return (
    <>
      <PageTitle
        eyebrow="YALNIZCA SANA AİT"
        title="Notlarım"
        description="Aklındakilere küçük bir yer aç."
        action={<AddButton onClick={() => setForm({})}>Yeni not</AddButton>}
      />
      <div className="privacy-banner">
        <LockKeyhole size={18} />
        <span>Özel alanın. Öğretmenin bu notları göremez.</span>
      </div>
      <Status {...q}>
        {({ notes, subjects }) => {
          const visible = notes
            .filter(
              (n) =>
                (filter === "all" || n.subjectId === filter) &&
                `${n.title} ${n.content}`
                  .toLocaleLowerCase("tr-TR")
                  .includes(search.toLocaleLowerCase("tr-TR")),
            )
            .sort(
              (a, b) =>
                Number(b.pinned) - Number(a.pinned) ||
                b.updatedAt.localeCompare(a.updatedAt),
            );
          return (
            <>
              <div className="notes-toolbar">
                <TextField
                  label="Notlarında ara"
                  value={search}
                  onChange={setSearch}
                  placeholder="Bir başlık veya kelime…"
                />
                <SelectField
                  label="Derse göre filtrele"
                  empty="Bütün dersler"
                  value={filter === "all" ? "" : filter}
                  onChange={(v) => setFilter(v || "all")}
                  options={subjects.map((s) => ({
                    value: s.id,
                    label: s.name,
                  }))}
                />
              </div>
              {visible.length ? (
                <div className="cards-grid notes-grid">
                  {visible.map((n) => (
                    <article className="item-card note-card" key={n.id}>
                      <div className="item-top">
                        <Badge>
                          {subjects.find((s) => s.id === n.subjectId)?.name ||
                            "Kişisel not"}
                        </Badge>
                        {n.pinned && (
                          <Badge>
                            <Pin size={13} />
                            Sabitlendi
                          </Badge>
                        )}
                      </div>
                      <h3>{n.title}</h3>
                      <p className="note-content">{n.content}</p>
                      <div className="note-actions">
                        <button
                          className="icon-btn"
                          aria-label={`${n.title} notunu düzenle`}
                          onClick={() => setForm({ note: n })}
                        >
                          <Pencil size={17} />
                        </button>
                        <button
                          className="icon-btn"
                          aria-label={
                            n.pinned
                              ? "Notun sabitlemesini kaldır"
                              : "Notu sabitle"
                          }
                          onClick={() => setPinning(n)}
                        >
                          <Pin size={17} />
                        </button>
                        <button
                          className="icon-btn"
                          aria-label={`${n.title} notunu sil`}
                          onClick={() => setDeleting(n)}
                        >
                          <Trash2 size={17} />
                        </button>
                      </div>
                    </article>
                  ))}
                </div>
              ) : (
                <div className="paper-panel">
                  <Empty
                    icon={<StickyNote size={32} />}
                    title={
                      notes.length
                        ? "Aramana uygun not yok."
                        : "Henüz özel notun yok."
                    }
                    description={
                      notes.length
                        ? "Başka bir kelime veya ders filtresi deneyebilirsin."
                        : "Bir düşünce, bir hatırlatma, kendine küçük bir not…"
                    }
                    action={notes.length ? "Aramayı temizle" : "İlk notumu yaz"}
                    onAction={() =>
                      notes.length
                        ? (setSearch(""), setFilter("all"))
                        : setForm({})
                    }
                  />
                </div>
              )}
              {form && (
                <NoteForm
                  existing={form.note}
                  subjects={subjects}
                  onClose={() => setForm(null)}
                />
              )}
            </>
          );
        }}
      </Status>
      {deleting && (
        <Confirm
          title="Not silinsin mi?"
          description="Bu özel not kalıcı olarak silinecek. Bu işlem geri alınamaz."
          onClose={() => setDeleting(null)}
          onConfirm={() => noteService.remove(deleting.id)}
        />
      )}{" "}
      {pinning && (
        <Modal
          title={pinning.pinned ? "Sabitlemeyi kaldır" : "Notunu sabitle"}
          onClose={() => setPinning(null)}
        >
          <SaveForm
            onSave={() =>
              noteService.update(pinning.id, { pinned: !pinning.pinned })
            }
            onSuccess={() => setPinning(null)}
          >
            <p>
              {pinning.pinned
                ? "Bu not normal sıralamasına dönecek."
                : "Bu not listenin en üstünde kalacak."}
            </p>
          </SaveForm>
        </Modal>
      )}
    </>
  );
}
