import { useState } from "react";
import {
  Plus,
  ChevronLeft,
  ChevronRight,
  CalendarDays,
  Trash2,
} from "lucide-react";
import type { WeeklyPlanItem, Homework } from "../models";
import { weeklyPlanService } from "../services/weeklyPlanService";
import { homeworkService } from "../services/homeworkService";
import { useQuery } from "../state/AppState";
import {
  PageTitle,
  AddButton,
  Status,
  Empty,
  Modal,
  SaveForm,
  TextField,
  TextArea,
  SelectField,
  Confirm,
  Badge,
} from "../components/ui";
import { weekDays } from "../validation";
import { localDate, dateLabel } from "../validation";
import { weekdays } from "../models/options";
const kindLabels = {
  homework: "Mevcut bir ödev",
  extra: "Ekstra çalışma",
  personal: "Kişisel çalışma planı",
  note: "Kısa not",
};
function PlanForm({
  date,
  existing,
  homework,
  onClose,
  onDelete,
}: {
  date: string;
  existing?: WeeklyPlanItem;
  homework: Homework[];
  onClose: () => void;
  onDelete?: (p: WeeklyPlanItem) => void;
}) {
  const [kind, setKind] = useState<WeeklyPlanItem["kind"]>(
    existing?.kind || "personal",
  );
  const [plannedDate, setDate] = useState(existing?.plannedDate || date);
  const [title, setTitle] = useState(existing?.title || "");
  const [note, setNote] = useState(existing?.note || "");
  const [homeworkId, setHomework] = useState(existing?.homeworkId || "");
  const h = homework.find((h) => h.id === homeworkId);
  return (
    <Modal
      title={existing ? "Planını düzenle" : "Planına ekle"}
      onClose={onClose}
    >
      <SaveForm
        validate={() =>
          kind !== "homework" && !title.trim() ? "Plan başlığını yaz." : null
        }
        onSave={() => {
          const data = {
            kind,
            plannedDate,
            title:
              kind === "homework"
                ? h?.description || existing?.title || ""
                : title.trim(),
            note,
            homeworkId: kind === "homework" ? homeworkId : null,
          };
          return existing
            ? weeklyPlanService.update(existing.id, data)
            : weeklyPlanService.create(data);
        }}
        onSuccess={onClose}
      >
        <SelectField
          label="Plan türü"
          value={kind}
          onChange={(v) => setKind(v as typeof kind)}
          required
          options={Object.entries(kindLabels).map(([value, label]) => ({
            value,
            label,
          }))}
        />
        {kind === "homework" ? (
          <>
            <SelectField
              label="Ödev"
              required
              value={homeworkId}
              onChange={setHomework}
              empty={homework.length ? "Ödev seç" : "Henüz ödev yok"}
              options={homework.map((h) => ({
                value: h.id,
                label: h.description,
              }))}
            />
            {h && (
              <p className="helper">
                Ödevin son teslim tarihi: {dateLabel(h.dueDate)}. Çalışma gününü
                değiştirmek teslim tarihini değiştirmez.
              </p>
            )}
          </>
        ) : (
          <TextField
            label="Plan başlığı"
            required
            value={title}
            onChange={setTitle}
          />
        )}
        <TextField
          label="Çalışmayı planladığın gün"
          type="date"
          required
          value={plannedDate}
          onChange={setDate}
        />
        <TextArea
          label="Kısa not (isteğe bağlı)"
          value={note}
          onChange={setNote}
        />
        {existing && onDelete && (
          <button
            type="button"
            className="btn danger secondary"
            onClick={() => onDelete(existing)}
          >
            <Trash2 size={16} />
            Plandan kaldır
          </button>
        )}
      </SaveForm>
    </Modal>
  );
}
export function PlanPage() {
  const [offset, setOffset] = useState(0);
  const dates = weekDays(offset);
  const [form, setForm] = useState<{
    date: string;
    item?: WeeklyPlanItem;
  } | null>(null);
  const [deleting, setDeleting] = useState<WeeklyPlanItem | null>(null);
  const q = useQuery(async () => {
    const [items, homework] = await Promise.all([
      weeklyPlanService.list(dates[0]),
      homeworkService.list(),
    ]);
    return { items, homework };
  }, [dates[0]]);
  return (
    <>
      <PageTitle
        eyebrow="ZAMANINI KENDİN PLANLA"
        title="Haftalık Plan"
        description="Çalışmaya da dinlenmeye de yer var."
        action={
          <AddButton onClick={() => setForm({ date: localDate() })}>
            Plana ekle
          </AddButton>
        }
      />
      <div className="week-controls">
        <div>
          <button
            className="icon-btn"
            aria-label="Önceki hafta"
            onClick={() => setOffset((x) => x - 1)}
          >
            <ChevronLeft />
          </button>
          <strong>
            {dateLabel(dates[0])} – {dateLabel(dates[6])} {dates[6].slice(0, 4)}
          </strong>
          <button
            className="icon-btn"
            aria-label="Sonraki hafta"
            onClick={() => setOffset((x) => x + 1)}
          >
            <ChevronRight />
          </button>
        </div>
        <button className="btn secondary small" onClick={() => setOffset(0)}>
          Bu hafta
        </button>
      </div>
      <Status {...q}>
        {({ items, homework }) => (
          <>
            {!items.length && (
              <div className="plan-empty-banner">
                <CalendarDays size={22} />
                <div>
                  <strong>Haftalık planın boş.</strong>
                  <span>Bir gün seçip ilk planını ekleyebilirsin.</span>
                </div>
              </div>
            )}
            <div className="weekly-grid">
              {dates.map((date, i) => (
                <section
                  key={date}
                  className={`day-column ${date === localDate() ? "is-today" : ""}`}
                >
                  <header>
                    <span>{weekdays[i]}</span>
                    <strong>{Number(date.slice(8))}</strong>
                    {date === localDate() && <Badge>Bugün</Badge>}
                  </header>
                  <div className="day-items">
                    {items
                      .filter((p) => p.plannedDate === date)
                      .map((p) => (
                        <button
                          key={p.id}
                          className="plan-item"
                          onClick={() => setForm({ date, item: p })}
                        >
                          <Badge>{kindLabels[p.kind]}</Badge>
                          <strong>{p.title}</strong>
                          {p.note && <span>{p.note}</span>}
                        </button>
                      ))}
                    {!items.some((p) => p.plannedDate === date) && (
                      <span className="day-empty">
                        Sana ayrılmış
                        <br />
                        bir sayfa.
                      </span>
                    )}
                  </div>
                  <button
                    className="day-add"
                    onClick={() => setForm({ date })}
                    aria-label={`${weekdays[i]} ${dateLabel(date)} gününe plan ekle`}
                  >
                    <Plus size={17} />
                    Ekle
                  </button>
                </section>
              ))}
            </div>
            <p className="page-hint">
              Bir planı başka güne taşımak için açıp çalışma gününü değiştir.
              Ödev teslim tarihi aynı kalır.
            </p>
            {form && (
              <PlanForm
                date={form.date}
                existing={form.item}
                homework={homework}
                onClose={() => setForm(null)}
                onDelete={(p) => {
                  setForm(null);
                  setDeleting(p);
                }}
              />
            )}
            {deleting && (
              <Confirm
                title="Bu plan kaldırılsın mı?"
                description="Yalnızca haftalık plan kaydı kaldırılır. Bağlı ödev silinmez."
                onClose={() => setDeleting(null)}
                onConfirm={() => weeklyPlanService.remove(deleting.id)}
              />
            )}
          </>
        )}
      </Status>
    </>
  );
}
