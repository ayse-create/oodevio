import { useState } from "react";
import { Plus, Trash2, ChartNoAxesCombined } from "lucide-react";
import type { MockExam, Subject, WrongTopic } from "../models";
import { mockExamService } from "../services/mockExamService";
import { subjectService } from "../services/subjectService";
import { apiConfig } from "../services/config";
import { useQuery } from "../state/AppState";
import {
  PageTitle,
  AddButton,
  Status,
  Empty,
  Tabs,
  Modal,
  SaveForm,
  TextField,
  TextArea,
  Badge,
} from "../components/ui";
import { SubjectSelect, WrongTopics } from "../components/DomainFields";
import { ExamAnalysis } from "../components/ExamAnalysis";
import {
  localDate,
  dateLabel,
  calculateNet,
  validateResults,
  isWhole,
} from "../validation";
type Row = {
  subjectId: string;
  correct: string;
  wrong: string;
  blank: string;
  wrongTopics: WrongTopic[];
};
function ExamForm({
  subjects,
  onClose,
}: {
  subjects: Subject[];
  onClose: () => void;
}) {
  const [name, setName] = useState("");
  const [date, setDate] = useState(localDate());
  const [score, setScore] = useState("");
  const [rank, setRank] = useState("");
  const [note, setNote] = useState("");
  const [penalty, setPenalty] = useState(String(apiConfig.netPenalty));
  const [rows, setRows] = useState<Row[]>([]);
  function update(i: number, patch: Partial<Row>) {
    setRows(rows.map((r, n) => (n === i ? { ...r, ...patch } : r)));
  }
  return (
    <Modal title="Deneme sonucunu ekle" onClose={onClose}>
      <SaveForm
        onSuccess={onClose}
        validate={() => {
          if (!name.trim()) return "Deneme adını yaz.";
          if (!rows.length) return "En az bir ders sonucu ekle.";
          if (new Set(rows.map((r) => r.subjectId)).size !== rows.length)
            return "Aynı ders yalnızca bir kez eklenebilir.";
          for (const r of rows) {
            const err = validateResults(
              Number(r.correct),
              Number(r.wrong),
              r.wrongTopics,
            );
            if (err) return err;
            if (!isWhole(Number(r.blank)))
              return "Boş sayısı sıfır veya pozitif tam sayı olmalı.";
            if (Number(r.correct) + Number(r.wrong) + Number(r.blank) < 1)
              return "Her ders için en az bir soru sonucu gir.";
          }
          return null;
        }}
        onSave={() =>
          mockExamService.create({
            name: name.trim(),
            date,
            netPenalty: Number(penalty),
            totalScore: Number(score),
            schoolRank: rank ? Number(rank) : null,
            note,
            subjectResults: rows.map((r) => ({
              subjectId: r.subjectId,
              correct: Number(r.correct),
              wrong: Number(r.wrong),
              blank: Number(r.blank),
              net: calculateNet(
                Number(r.correct),
                Number(r.wrong),
                Number(penalty),
              ),
              wrongTopics: Number(r.wrong) > 0 ? r.wrongTopics : [],
            })),
          })
        }
      >
        <TextField
          label="Deneme adı"
          required
          value={name}
          onChange={setName}
        />
        <div className="form-grid">
          <TextField
            label="Deneme tarihi"
            type="date"
            max={localDate()}
            required
            value={date}
            onChange={setDate}
          />
          <TextField
            label="Bir doğruyu götüren yanlış sayısı"
            type="number"
            min={1}
            step={1}
            required
            value={penalty}
            onChange={setPenalty}
          />
        </div>
        <p className="helper">
          Net = Doğru − (Yanlış ÷ {penalty || "…"}). Denemenin kuralına göre
          değiştirebilirsin.
        </p>
        <fieldset>
          <legend>Ders sonuçları</legend>
          {rows.map((r, i) => (
            <div className="exam-row" key={i}>
              <div className="exam-row-top">
                <strong>{i + 1}. ders</strong>
                <button
                  type="button"
                  className="icon-btn"
                  aria-label={`${i + 1}. ders sonucunu kaldır`}
                  onClick={() => setRows(rows.filter((_, n) => n !== i))}
                >
                  <Trash2 size={18} />
                </button>
              </div>
              <SubjectSelect
                subjects={subjects.filter(
                  (s) =>
                    s.id === r.subjectId ||
                    !rows.some((x) => x.subjectId === s.id),
                )}
                value={r.subjectId}
                onChange={(v) => update(i, { subjectId: v })}
              />
              <div className="exam-numbers">
                <TextField
                  label="Doğru"
                  type="number"
                  min={0}
                  step={1}
                  required
                  value={r.correct}
                  onChange={(v) => update(i, { correct: v })}
                />
                <TextField
                  label="Yanlış"
                  type="number"
                  min={0}
                  step={1}
                  required
                  value={r.wrong}
                  onChange={(v) => update(i, { wrong: v })}
                />
                <TextField
                  label="Boş"
                  type="number"
                  min={0}
                  step={1}
                  required
                  value={r.blank}
                  onChange={(v) => update(i, { blank: v })}
                />
                <div className="net-result">
                  <span>Net</span>
                  <output>
                    {r.correct !== "" && r.wrong !== "" && Number(penalty) > 0
                      ? calculateNet(
                          Number(r.correct),
                          Number(r.wrong),
                          Number(penalty),
                        )
                      : "—"}
                  </output>
                </div>
              </div>
              <WrongTopics
                value={r.wrongTopics}
                onChange={(v) => update(i, { wrongTopics: v })}
                wrong={Number(r.wrong)}
              />
            </div>
          ))}
          <button
            type="button"
            className="btn secondary"
            onClick={() =>
              setRows([
                ...rows,
                {
                  subjectId: "",
                  correct: "",
                  wrong: "",
                  blank: "",
                  wrongTopics: [],
                },
              ])
            }
          >
            <Plus size={17} />
            Ders sonucu ekle
          </button>
        </fieldset>
        <div className="form-grid">
          <TextField
            label="Toplam puan"
            type="number"
            min={0}
            step={0.01}
            required
            value={score}
            onChange={setScore}
          />
          <TextField
            label="Okul sıralaması (isteğe bağlı)"
            type="number"
            min={1}
            step={1}
            value={rank}
            onChange={setRank}
          />
        </div>
        <TextArea label="Not (isteğe bağlı)" value={note} onChange={setNote} />
      </SaveForm>
    </Modal>
  );
}
export function ExamCard({
  exam: e,
  subjects,
}: {
  exam: MockExam;
  subjects: Subject[];
}) {
  return (
    <article className="item-card exam-card">
      <div className="item-top">
        <Badge>{dateLabel(e.date)}</Badge>
        <strong>{e.totalScore} puan</strong>
      </div>
      <h3>{e.name}</h3>
      <p>
        Toplam net: {e.subjectResults.reduce((s, r) => s + r.net, 0).toFixed(2)}
        {e.schoolRank !== null ? ` · Okul sırası: ${e.schoolRank}` : ""}
      </p>
      <div className="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Ders</th>
              <th>Doğru</th>
              <th>Yanlış</th>
              <th>Boş</th>
              <th>Net</th>
            </tr>
          </thead>
          <tbody>
            {e.subjectResults.map((r) => (
              <tr key={r.subjectId}>
                <td>
                  {subjects.find((s) => s.id === r.subjectId)?.name || "Ders"}
                </td>
                <td>{r.correct}</td>
                <td>{r.wrong}</td>
                <td>{r.blank}</td>
                <td>
                  <strong>{r.net}</strong>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {e.note && <p className="helper">{e.note}</p>}
    </article>
  );
}
export function ExamsPage() {
  const [tab, setTab] = useState("results");
  const [open, setOpen] = useState(false);
  const q = useQuery(async () => {
    const [exams, subjects] = await Promise.all([
      mockExamService.list(),
      subjectService.listSelected(),
    ]);
    return { exams, subjects };
  });
  return (
    <>
      <PageTitle
        eyebrow="GELİŞİMİNİ GÖR"
        title="Deneme Sonuçları"
        description="Bir sonuçtan fazlası: zaman içindeki ilerlemen."
        action={
          <AddButton onClick={() => setOpen(true)}>Deneme ekle</AddButton>
        }
      />
      <Tabs
        value={tab}
        onChange={setTab}
        items={[
          { id: "results", label: "Denemelerim" },
          { id: "analysis", label: "Son üç ay · Gelişim" },
        ]}
      />
      <Status {...q}>
        {({ exams, subjects }) => (
          <>
            {tab === "analysis" ? (
              <ExamAnalysis exams={exams} subjects={subjects} />
            ) : exams.length ? (
              <div className="cards-grid">
                {[...exams]
                  .sort((a, b) => b.date.localeCompare(a.date))
                  .map((e) => (
                    <ExamCard key={e.id} exam={e} subjects={subjects} />
                  ))}
              </div>
            ) : (
              <div className="paper-panel">
                <Empty
                  icon={<ChartNoAxesCombined size={34} />}
                  title="Henüz deneme sonucun yok."
                  description="İlk deneme sonucunu ekle, ilerlemeni birlikte takip edelim."
                  action="Deneme sonucu ekle"
                  onAction={() => setOpen(true)}
                />
              </div>
            )}
            {open && (
              <ExamForm subjects={subjects} onClose={() => setOpen(false)} />
            )}
          </>
        )}
      </Status>
    </>
  );
}
