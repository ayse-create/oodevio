import { useEffect, useState } from "react";
import { NavLink, Outlet, useLocation, Link } from "react-router-dom";
import {
  Home,
  BookOpen,
  BookX,
  Target,
  ChartNoAxesCombined,
  CalendarDays,
  StickyNote,
  Settings,
  Menu,
  X,
  ArrowUpRight,
  GraduationCap,
  Users,
  Heart,
  ChevronRight,
} from "lucide-react";
import { Modal, Empty } from "../components/ui";
import { apiConfig } from "../services/config";
import { useTheme, themes } from "../theme/ThemeProvider";
import { useApp } from "../state/AppState";
const studentItems = [
  { to: "/ogrenci", label: "Ana Sayfa", icon: Home },
  { to: "/ogrenci/odevler", label: "Ödevler", icon: BookOpen },
  { to: "/ogrenci/yanlislar", label: "Yanlış Defteri", icon: BookX },
  { to: "/ogrenci/hedefler", label: "Ekstralar ve Hedefler", icon: Target },
  {
    to: "/ogrenci/denemeler",
    label: "Deneme Sonuçları",
    icon: ChartNoAxesCombined,
  },
  { to: "/ogrenci/plan", label: "Haftalık Plan", icon: CalendarDays },
  { to: "/ogrenci/notlar", label: "Notlar", icon: StickyNote },
  { to: "/ogrenci/ayarlar", label: "Ayarlar", icon: Settings },
];
const teacherItems = [
  { to: "/ogretmen", label: "Öğrencilerim", icon: Users },
  { to: "/ogretmen/ayarlar", label: "Ayarlar", icon: Settings },
];
export function NotebookLayout({ role }: { role: "student" | "teacher" }) {
  const [menu, setMenu] = useState(false);
  const location = useLocation();
  const { theme, setTheme } = useTheme();
  const { session, sessionReady } = useApp();
  const items = role === "student" ? studentItems : teacherItems;
  useEffect(() => {
    setMenu(false);
    document.getElementById("main-content")?.focus();
  }, [location.pathname]);
  const links = (
    <>
      {items.map(({ to, label, icon: Icon }) => (
        <NavLink
          key={to}
          to={to}
          end={to === "/ogrenci" || to === "/ogretmen"}
          className={({ isActive }) => `nav-item ${isActive ? "active" : ""}`}
        >
          <Icon size={20} />
          <span>{label}</span>
          <ChevronRight className="nav-chevron" size={16} />
        </NavLink>
      ))}
    </>
  );
  if (!sessionReady)
    return (
      <div className="status" role="status">
        Oturum kontrol ediliyor…
      </div>
    );
  if (apiConfig.enabled && (!session || session.role !== role))
    return (
      <div className="entry-page">
        <Empty
          title="Bu sayfaya erişilemiyor."
          description={
            session
              ? "Bu sayfa diğer kullanıcı rolüne ait."
              : "Devam etmek için hesabına giriş yapmalısın."
          }
          action="Giriş ekranına git"
          to="/giris"
        />
      </div>
    );
  return (
    <div className="workspace">
      <a href="#main-content" className="skip-link">
        İçeriğe geç
      </a>
      <aside className="sidebar">
        <Link to="/" className="brand">
          ödevio<span>✳</span>
        </Link>
        <span className="sidebar-label">
          {role === "student" ? "BENİM DEFTERİM" : "ÖĞRETMEN DEFTERİ"}
        </span>
        <nav aria-label="Ana menü">{links}</nav>
        <div className="sidebar-bottom">
          <div className="theme-dots" role="group" aria-label="Tema seçimi">
            {themes.map((t) => (
              <button
                key={t.id}
                aria-label={`${t.label} tema`}
                aria-pressed={theme === t.id}
                style={{ background: t.color }}
                className={theme === t.id ? "chosen" : ""}
                onClick={() => setTheme(t.id)}
              />
            ))}
          </div>
          <Link to="/giris" className="role-switch">
            <GraduationCap size={19} />
            {role === "student"
              ? "Öğretmen girişine geç"
              : "Öğrenci girişine geç"}
            <ArrowUpRight size={16} />
          </Link>
        </div>
      </aside>
      <div className="notebook">
        <div className="binding" aria-hidden="true">
          {Array.from({ length: 11 }, (_, i) => (
            <span key={i} />
          ))}
        </div>
        <header className="topbar">
          <div className="breadcrumb">
            <BookOpen size={17} />
            <span>
              {role === "student" ? "Çalışma defterim" : "Öğretmen defterim"}
            </span>
            <ChevronRight size={14} />
            <strong>
              {items.find((i) => i.to === location.pathname)?.label ||
                "Ayrıntılar"}
            </strong>
          </div>
          <div className="top-actions">
            {!session && (
              <span className="preview-label">Hesapsız inceleme</span>
            )}
            <button
              className="icon-btn menu-button"
              aria-label="Menüyü aç"
              aria-expanded={menu}
              onClick={() => setMenu(true)}
            >
              <Menu size={22} />
            </button>
          </div>
        </header>
        <main
          id="main-content"
          tabIndex={-1}
          key={location.pathname}
          className="page-content page-turn"
        >
          <Outlet />
        </main>
        <footer className="page-footer">
          <span>
            Ödevio ·{" "}
            {role === "student"
              ? "Her şey bir sayfayla başlar."
              : "Birlikte daha ileriye."}
          </span>
          <Heart size={13} />
          <span>{new Date().getFullYear()}</span>
        </footer>
      </div>
      {menu && (
        <Modal title="Defterindeki sayfalar" onClose={() => setMenu(false)}>
          <nav className="drawer-nav" aria-label="Açılır menü">
            {links}
          </nav>
          <Link
            className="btn secondary"
            to="/giris"
            onClick={() => setMenu(false)}
          >
            Giriş ekranına dön
          </Link>
        </Modal>
      )}
    </div>
  );
}
