import type { StudentProfile, DailySummary } from "../models";
import { request } from "./client";
import { apiConfig } from "./config";
const base = apiConfig.endpoints.student;
export const studentService = {
  getProfile: () => request<StudentProfile | null>(base, { empty: null }),
  updateProfile: (input: Partial<Omit<StudentProfile, "id" | "studentCode">>) =>
    request<StudentProfile>(base, { method: "PATCH", body: input }),
  getDailySummary: (date: string) =>
    request<DailySummary>(`${base}/summary?date=${encodeURIComponent(date)}`, {
      empty: {
        totalQuestions: 0,
        correct: 0,
        wrong: 0,
        target: 0,
        completedHomework: 0,
      },
    }),
};
