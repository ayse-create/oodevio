import type { DailyGoal, DailyPracticeResult } from "../models";
import { request, idPath, query } from "./client";
import { apiConfig } from "./config";
const b = apiConfig.endpoints.goals;
export const goalService = {
  list: () => request<DailyGoal[]>(b, { empty: [] }),
  create: (input: Omit<DailyGoal, "id" | "studentId">) =>
    request<DailyGoal>(b, { method: "POST", body: input }),
  update: (id: string, input: Omit<DailyGoal, "id" | "studentId">) =>
    request<DailyGoal>(`${b}/${idPath(id)}`, { method: "PATCH", body: input }),
  listResults: (date?: string) =>
    request<DailyPracticeResult[]>(
      `${apiConfig.endpoints.practice}${query({ date })}`,
      { empty: [] },
    ),
  recordPractice: (input: Omit<DailyPracticeResult, "id" | "studentId">) =>
    request<DailyPracticeResult>(apiConfig.endpoints.practice, {
      method: "POST",
      body: input,
    }),
};
