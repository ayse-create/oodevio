import type { MessagePreset, TeacherMessage } from "../models";
import { request } from "./client";
import { apiConfig } from "./config";
export const messageService = {
  listReceived: () =>
    request<TeacherMessage[]>(apiConfig.endpoints.messages, { empty: [] }),
  send: (studentId: string, preset: MessagePreset) =>
    request<TeacherMessage>(apiConfig.endpoints.messages, {
      method: "POST",
      body: { studentId, preset },
    }),
};
