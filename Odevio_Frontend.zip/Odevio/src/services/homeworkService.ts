import type { Homework, HomeworkCompletion } from "../models";
import { request, idPath } from "./client";
import { apiConfig } from "./config";
const b = apiConfig.endpoints.homework;
export const homeworkService = {
  list: () => request<Homework[]>(b, { empty: [] }),
  get: (id: string) =>
    request<Homework | null>(`${b}/${idPath(id)}`, { empty: null }),
  create: (input: Omit<Homework, "id" | "studentId" | "status">) =>
    request<Homework>(b, { method: "POST", body: input }),
  update: (
    id: string,
    input: Partial<Omit<Homework, "id" | "studentId" | "status">>,
  ) =>
    request<Homework>(`${b}/${idPath(id)}`, { method: "PATCH", body: input }),
  complete: (
    id: string,
    input: Pick<HomeworkCompletion, "correct" | "wrong" | "wrongTopics">,
  ) =>
    request<HomeworkCompletion>(`${b}/${idPath(id)}/completion`, {
      method: "POST",
      body: input,
    }),
};
