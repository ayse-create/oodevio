import type { MockExam } from "../models";
import { request } from "./client";
import { apiConfig } from "./config";
export const mockExamService = {
  list: () => request<MockExam[]>(apiConfig.endpoints.exams, { empty: [] }),
  create: (input: Omit<MockExam, "id" | "studentId">) =>
    request<MockExam>(apiConfig.endpoints.exams, {
      method: "POST",
      body: input,
    }),
};
