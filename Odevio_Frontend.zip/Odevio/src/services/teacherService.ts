import type {
  TeacherProfile,
  TeacherStudentLink,
  TeacherStudentOverview,
} from "../models";
import { request, idPath } from "./client";
import { apiConfig } from "./config";
const base = apiConfig.endpoints.teacher;
// An explicit allowlist prevents accidental private-note data entering teacher components.
const publicOverview = (
  v: TeacherStudentOverview | null,
): TeacherStudentOverview | null =>
  v
    ? {
        student: {
          id: v.student.id,
          name: v.student.name,
          grade: v.student.grade,
          avatar: v.student.avatar,
        },
        summary: v.summary,
        homework: v.homework,
        completions: v.completions,
        goals: v.goals,
        practices: v.practices,
        wrongEntries: v.wrongEntries,
        mockExams: v.mockExams,
        subjects: v.subjects,
      }
    : null;
export const teacherService = {
  getProfile: () => request<TeacherProfile | null>(base, { empty: null }),
  updateProfile: (input: Partial<Omit<TeacherProfile, "id">>) =>
    request<TeacherProfile>(base, { method: "PATCH", body: input }),
  listStudents: () =>
    request<TeacherStudentLink[]>(`${base}/students`, { empty: [] }),
  linkStudent: (studentCode: string) =>
    request<TeacherStudentLink>(`${base}/students`, {
      method: "POST",
      body: { studentCode },
    }),
  getStudent: async (id: string) =>
    publicOverview(
      await request<TeacherStudentOverview | null>(
        `${base}/students/${idPath(id)}`,
        { empty: null },
      ),
    ),
};
