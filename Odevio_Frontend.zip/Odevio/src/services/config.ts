const env = import.meta.env ?? {};
export const apiConfig = {
  enabled: env.VITE_API_ENABLED === "true",
  baseUrl: String(env.VITE_API_BASE_URL || "").replace(/\/$/, ""),
  timeoutMs: 15000,
  netPenalty:
    Number(env.VITE_NET_PENALTY) > 0 ? Number(env.VITE_NET_PENALTY) : 4,
  endpoints: {
    auth: "/auth",
    student: "/students/me",
    teacher: "/teachers/me",
    subjects: "/subjects",
    homework: "/homework",
    wrongs: "/wrong-entries",
    goals: "/goals",
    practice: "/practice-results",
    exams: "/mock-exams",
    plan: "/weekly-plan",
    notes: "/private-notes",
    messages: "/messages",
  },
} as const;
