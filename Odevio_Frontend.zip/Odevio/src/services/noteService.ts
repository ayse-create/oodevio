import type { PrivateNote } from "../models";
import { request, idPath } from "./client";
import { apiConfig } from "./config";
const b = apiConfig.endpoints.notes;
export const noteService = {
  list: () => request<PrivateNote[]>(b, { empty: [] }),
  create: (
    input: Pick<PrivateNote, "title" | "content" | "subjectId" | "pinned">,
  ) => request<PrivateNote>(b, { method: "POST", body: input }),
  update: (
    id: string,
    input: Partial<
      Pick<PrivateNote, "title" | "content" | "subjectId" | "pinned">
    >,
  ) =>
    request<PrivateNote>(`${b}/${idPath(id)}`, {
      method: "PATCH",
      body: input,
    }),
  remove: (id: string) =>
    request<void>(`${b}/${idPath(id)}`, { method: "DELETE" }),
};
