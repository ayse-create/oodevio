import type { Subject } from "../models";
import { request } from "./client";
import { apiConfig } from "./config";
export const subjectService = {
  list: () => request<Subject[]>(apiConfig.endpoints.subjects, { empty: [] }),
  listSelected: () =>
    request<Subject[]>(`${apiConfig.endpoints.student}/subjects`, {
      empty: [],
    }),
  setSelected: (subjectIds: string[]) =>
    request<Subject[]>(`${apiConfig.endpoints.student}/subjects`, {
      method: "PATCH",
      body: { subjectIds },
    }),
};
