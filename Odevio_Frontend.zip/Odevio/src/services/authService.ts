import type { StudentProfile, Session } from "../models";
import { request } from "./client";
import { apiConfig } from "./config";
const base = apiConfig.endpoints.auth;
export const authService = {
  session: () => request<Session | null>(`${base}/session`, { empty: null }),
  registerStudent: (
    input: Omit<StudentProfile, "id" | "studentCode" | "theme">,
  ) => request<Session>(`${base}/students`, { method: "POST", body: input }),
  loginStudent: (studentCode: string) =>
    request<Session>(`${base}/student-login`, {
      method: "POST",
      body: { studentCode },
    }),
  loginTeacher: (email: string, password: string) =>
    request<Session>(`${base}/teacher-login`, {
      method: "POST",
      body: { email, password },
    }),
  logout: () => request<void>(`${base}/logout`, { method: "POST" }),
  deleteAccount: () => request<void>(`${base}/account`, { method: "DELETE" }),
};
