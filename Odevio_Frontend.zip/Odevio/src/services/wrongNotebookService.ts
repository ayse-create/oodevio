import type { WrongEntry, StudyMethod } from "../models";
import { request, idPath } from "./client";
import { apiConfig } from "./config";
const b = apiConfig.endpoints.wrongs;
export const wrongNotebookService = {
  list: (view: "current" | "history") =>
    request<WrongEntry[]>(`${b}?view=${view}`, { empty: [] }),
  markStudied: (id: string, studyMethods: StudyMethod[]) =>
    request<WrongEntry>(`${b}/${idPath(id)}/study`, {
      method: "PATCH",
      body: { studied: studyMethods.length > 0, studyMethods },
    }),
};
