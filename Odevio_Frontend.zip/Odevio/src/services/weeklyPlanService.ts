import type { WeeklyPlanItem } from "../models";
import { request, idPath } from "./client";
import { apiConfig } from "./config";
const b = apiConfig.endpoints.plan;
export const weeklyPlanService = {
  list: (weekStart: string) =>
    request<WeeklyPlanItem[]>(
      `${b}?weekStart=${encodeURIComponent(weekStart)}`,
      { empty: [] },
    ),
  create: (input: Omit<WeeklyPlanItem, "id" | "studentId">) =>
    request<WeeklyPlanItem>(b, { method: "POST", body: input }),
  update: (
    id: string,
    input: Partial<Omit<WeeklyPlanItem, "id" | "studentId">>,
  ) =>
    request<WeeklyPlanItem>(`${b}/${idPath(id)}`, {
      method: "PATCH",
      body: input,
    }),
  remove: (id: string) =>
    request<void>(`${b}/${idPath(id)}`, { method: "DELETE" }),
};
