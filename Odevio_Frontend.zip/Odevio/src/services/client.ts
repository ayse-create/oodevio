import { apiConfig } from "./config";
export class ApiError extends Error {
  constructor(
    message: string,
    public code:
      | "UNAVAILABLE"
      | "UNAUTHORIZED"
      | "FORBIDDEN"
      | "NETWORK"
      | "VALIDATION"
      | "SERVER",
    public status?: number,
  ) {
    super(message);
    this.name = "ApiError";
  }
}
export async function request<T>(
  path: string,
  options: {
    method?: "GET" | "POST" | "PATCH" | "DELETE";
    body?: unknown;
    empty?: T;
    signal?: AbortSignal;
  } = {},
): Promise<T> {
  const method = options.method || "GET";
  if (!apiConfig.enabled) {
    if (method === "GET" && "empty" in options) return options.empty as T;
    throw new ApiError(
      "Henüz bağlantı kurulmadı. Bu işlem kaydedilmedi; bağlantı hazır olduğunda yeniden deneyebilirsin.",
      "UNAVAILABLE",
    );
  }
  const controller = new AbortController();
  const abort = () => controller.abort();
  options.signal?.addEventListener("abort", abort, { once: true });
  if (options.signal?.aborted) controller.abort();
  const timeout = setTimeout(abort, apiConfig.timeoutMs);
  try {
    const response = await fetch(`${apiConfig.baseUrl}${path}`, {
      method,
      credentials: "include",
      headers: {
        Accept: "application/json",
        ...(options.body !== undefined
          ? { "Content-Type": "application/json" }
          : {}),
      },
      body:
        options.body === undefined ? undefined : JSON.stringify(options.body),
      signal: controller.signal,
    });
    if (!response.ok) {
      if (response.status === 401)
        throw new ApiError(
          "Bu sayfayı kullanmak için hesabına giriş yapmalısın.",
          "UNAUTHORIZED",
          401,
        );
      if (response.status === 403)
        throw new ApiError("Bu bilgilere erişim iznin yok.", "FORBIDDEN", 403);
      throw new ApiError(
        response.status === 422
          ? "Girdiğin bilgileri kontrol edip tekrar dene."
          : "İşlem tamamlanamadı. Biraz sonra yeniden dene.",
        response.status === 422 ? "VALIDATION" : "SERVER",
        response.status,
      );
    }
    if (response.status === 204) return undefined as T;
    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof ApiError) throw error;
    throw new ApiError(
      "Bağlantı kurulamadı veya istek zaman aşımına uğradı. Yeniden deneyebilirsin.",
      "NETWORK",
    );
  } finally {
    clearTimeout(timeout);
    options.signal?.removeEventListener("abort", abort);
  }
}
export const query = (params: Record<string, string | undefined>) => {
  const q = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined) q.set(k, v);
  });
  return q.size ? `?${q}` : "";
};
export const idPath = (id: string) => encodeURIComponent(id);
