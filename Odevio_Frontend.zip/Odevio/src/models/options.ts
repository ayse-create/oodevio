import type { StudyMethod, MessagePreset, WrongSource } from "./index";
export const studyMethods: Record<StudyMethod, string> = {
  questions: "Soru çözdüm",
  video: "Video izledim",
  topic: "Konu çalıştım",
  teacher: "Öğretmene sordum",
  review: "Tekrar yaptım",
};
export const messagePresets: Record<MessagePreset, string> = {
  heart: "Kalp",
  check: "Onay işareti",
  great: "Harika",
  "going-well": "Çok iyi gidiyorsun",
  "study-more": "Biraz daha çalışmalısın",
  "try-again": "Yeniden deneyebilirsin",
};
export const sourceLabels: Record<WrongSource, string> = {
  homework: "Ödev",
  goal: "Günlük hedef",
  extra: "Ekstra çalışma",
  "mock-exam": "Deneme yanlışı",
};
export const weekdays = [
  "Pazartesi",
  "Salı",
  "Çarşamba",
  "Perşembe",
  "Cuma",
  "Cumartesi",
  "Pazar",
];
