export type ID = string;
export type DateOnly = string;
export type ThemeName = "pink" | "blue" | "green" | "yellow" | "orange";
export interface StudentProfile {
  id: ID;
  name: string;
  avatar: string | null;
  grade: string;
  school: string;
  subjectIds: ID[];
  studentCode: string;
  theme: ThemeName;
}
export interface TeacherProfile {
  id: ID;
  name: string;
  email: string;
  branch: string;
}
export interface Subject {
  id: ID;
  name: string;
  color?: string;
}
export interface WrongTopic {
  topic: string;
  count: number;
}
export interface Homework {
  id: ID;
  studentId: ID;
  subjectId: ID;
  description: string;
  assignedDate: DateOnly;
  dueDate: DateOnly;
  totalQuestions: number;
  teacherNote: string;
  status: "pending" | "completed";
}
export interface HomeworkCompletion {
  id: ID;
  homeworkId: ID;
  correct: number;
  wrong: number;
  wrongTopics: WrongTopic[];
  completedAt: string;
}
export type StudyMethod =
  "questions" | "video" | "topic" | "teacher" | "review";
export type WrongSource = "homework" | "goal" | "extra" | "mock-exam";
export interface WrongEntry {
  id: ID;
  studentId: ID;
  subjectId: ID;
  topic: string;
  wrongCount: number;
  source: WrongSource;
  sourceId: ID;
  date: DateOnly;
  studied: boolean;
  studyMethods: StudyMethod[];
  archivedAt: string | null;
}
export type GoalPattern =
  | { type: "once"; date: DateOnly }
  | { type: "daily"; startDate: DateOnly }
  | { type: "weekdays"; days: number[]; startDate: DateOnly }
  | { type: "alternating"; subjectIds: ID[]; startDate: DateOnly };
export interface DailyGoal {
  id: ID;
  studentId: ID;
  title: string;
  subjectId: ID;
  questionTarget: number;
  pattern: GoalPattern;
  active: boolean;
}
export interface DailyPracticeResult {
  id: ID;
  studentId: ID;
  goalId: ID | null;
  subjectId: ID;
  date: DateOnly;
  correct: number;
  wrong: number;
  wrongTopics: WrongTopic[];
  source: "goal" | "extra";
}
export interface MockExamSubjectResult {
  subjectId: ID;
  correct: number;
  wrong: number;
  blank: number;
  net: number;
  wrongTopics: WrongTopic[];
}
export interface MockExam {
  id: ID;
  studentId: ID;
  name: string;
  date: DateOnly;
  subjectResults: MockExamSubjectResult[];
  netPenalty: number;
  totalScore: number;
  schoolRank: number | null;
  note: string;
}
export interface WeeklyPlanItem {
  id: ID;
  studentId: ID;
  plannedDate: DateOnly;
  kind: "homework" | "extra" | "personal" | "note";
  homeworkId: ID | null;
  title: string;
  note: string;
}
export interface PrivateNote {
  id: ID;
  studentId: ID;
  title: string;
  content: string;
  subjectId: ID | null;
  pinned: boolean;
  updatedAt: string;
}
export interface TeacherStudentLink {
  id: ID;
  teacherId: ID;
  student: Pick<StudentProfile, "id" | "name" | "grade" | "avatar">;
  linkedAt: string;
}
export type MessagePreset =
  "heart" | "check" | "great" | "going-well" | "study-more" | "try-again";
export interface TeacherMessage {
  id: ID;
  teacherId: ID;
  studentId: ID;
  preset: MessagePreset;
  sentAt: string;
  teacherName: string;
}
export interface DailySummary {
  totalQuestions: number;
  correct: number;
  wrong: number;
  target: number;
  completedHomework: number;
}
export interface TeacherStudentOverview {
  student: Pick<StudentProfile, "id" | "name" | "grade" | "avatar">;
  summary: DailySummary;
  homework: Homework[];
  completions: HomeworkCompletion[];
  goals: DailyGoal[];
  practices: DailyPracticeResult[];
  wrongEntries: WrongEntry[];
  mockExams: MockExam[];
  subjects: Subject[];
}
export interface Session {
  role: "student" | "teacher";
  userId: ID;
}
export type NewEntity<T> = Omit<T, "id">;
export type RequestState<T> =
  | { status: "loading" }
  | { status: "error"; error: Error }
  | { status: "success"; data: T };
