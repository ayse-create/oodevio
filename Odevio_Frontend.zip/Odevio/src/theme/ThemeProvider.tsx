import {
  createContext,
  useContext,
  useState,
  useEffect,
  type ReactNode,
} from "react";
import type { ThemeName } from "../models";
export const themes: { id: ThemeName; label: string; color: string }[] = [
  { id: "pink", label: "Pembe", color: "#ba3c69" },
  { id: "blue", label: "Mavi", color: "#3165a6" },
  { id: "green", label: "Yeşil", color: "#287051" },
  { id: "yellow", label: "Sarı", color: "#936513" },
  { id: "orange", label: "Turuncu", color: "#ad4d22" },
];
const ThemeContext = createContext({
  theme: "pink" as ThemeName,
  setTheme: (_t: ThemeName) => {},
});
export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setTheme] = useState<ThemeName>("pink");
  useEffect(() => {
    document.documentElement.dataset.theme = theme;
  }, [theme]);
  return (
    <ThemeContext.Provider value={{ theme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}
export const useTheme = () => useContext(ThemeContext);
export function ThemePicker() {
  const { theme, setTheme } = useTheme();
  return (
    <div className="theme-picker" role="group" aria-label="Defter rengi">
      {themes.map((t) => (
        <button
          type="button"
          key={t.id}
          className={theme === t.id ? "theme-choice selected" : "theme-choice"}
          onClick={() => setTheme(t.id)}
          aria-pressed={theme === t.id}
          aria-label={`${t.label} tema`}
        >
          <span style={{ background: t.color }} />
          {t.label}
          {theme === t.id && <span className="theme-tick">✓</span>}
        </button>
      ))}
    </div>
  );
}
